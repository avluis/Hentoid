"use strict";
var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function(e) {
    return typeof e
} : function(e) {
    return e && typeof Symbol === "function" && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
};
var N = window.N = {};
N.init = function() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    N.options = e;
    for (var t in this) {
        if (this.hasOwnProperty(t) && /^(install|patch)_/.test(t)) {
            this[t]()
        }
    }
};
N.install_analytics = function() {
    window.GoogleAnalyticsObject = "ga";
    window.ga = window.ga || function() {
        (window.ga.q = window.ga.q || []).push(arguments)
    };
    window.ga.l = +new Date;
    N.inject_script("https://www.google-analytics.com/analytics.js", {
        async: true
    });
    window.ga("create", "UA-52345677-1", {
        sampleRate: 1
    });
    window.ga("send", "pageview")
};
N.patch_safari_touch_hover = function() {
    N.bind(document, "touchstart", function() {}, {
        capture: true,
        passive: true
    })
};
N.patch_no_console = function() {
    if (window.console) {
        return
    }
    window.console = {
        log: function e() {},
        debug: function t() {},
        error: function n() {}
    }
};
N.install_tag_blacklisting = function() {
    var e = N.options.blacklisted_tags;
    if (!e || !e.length) {
        return
    }
    var t = e.map(function(e) {
        return N.format('.tag-{0},.gallery[data-tags~="{0}"]', e)
    }).join(",");
    var n = document.querySelectorAll(t);
    for (var r = 0; r < n.length; r++) {
        n[r].classList.add("blacklisted")
    }
};
N.key = {
    BACKSPACE: 8,
    TAB: 9,
    ENTER: 13,
    SHIFT: 16,
    CTRL: 17,
    ALT: 18,
    ESCAPE: 27,
    SPACEBAR: 32,
    LEFT_ARROW: 37,
    UP_ARROW: 38,
    RIGHT_ARROW: 39,
    DOWN_ARROW: 40,
    A: 65,
    D: 68,
    S: 83,
    W: 87
};
N.cookies = {};
N.cookies.get = function(e, t) {
    var n = document.cookie.split(/;\s*/);
    for (var r = 0; r < n.length; r++) {
        var a = n[r];
        if (a.indexOf(e + "=") === 0) {
            return a.split("=", 2)[1]
        }
    }
    return t
};
N.cookies.has = function(e) {
    return N.cookies.get(e, false) !== false
};
N.cookies.set = function(e, t, n) {
    var r = [e + "=" + t];
    if (n) {
        var a = new Date;
        a.setTime(a.getTime() + n * 1e3);
        r.push("expires=" + a.toUTCString())
    }
    r.push("path=/");
    document.cookie = r.join("; ")
};
N.cookies.delete = function(e) {
    return N.cookies.set(e, "", -1)
};
N.bind = function() {
    if (typeof arguments[2] === "string") {
        return N.bind_dynamic.apply(null, arguments)
    } else {
        return N.bind_regular.apply(null, arguments)
    }
};
N.bind_dynamic = function(e, t, n, r) {
    var a = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : {
        capture: true
    };
    var i = function o(e) {
        var n = N.find_parent(e.target, t, a);
        if (n) {
            return r.apply(n, arguments)
        }
    };
    N.bind_regular(e, n, i, a);
    return i
};
N.bind_regular = function(e, t, n) {
    var r = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : {
        capture: true
    };
    if (typeof e === "string") {
        e = document.querySelectorAll(e)
    } else if (!(e instanceof NodeList) && e.constructor !== Array) {
        e = [e]
    }
    var t = t.split(/\s+/);
    for (var a = 0; a < e.length; a++) {
        var i = e[a];
        for (var o = 0; o < t.length; o++) {
            if (t[o] === "load" && i instanceof HTMLImageElement && (i.naturalHeight || i.complete)) {
                n(i)
            } else {
                i.addEventListener(t[o], n, N.browser.supports_passive_events ? r : r.capture || false)
            }
        }
    }
    return n
};
N.bind_once = function(e, t, n) {
    var r = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : {
        capture: true
    };
    var a = function i() {
        N.unbind(e, t, i, r);
        n.apply(this, arguments)
    };
    return N.bind_regular(e, t, a, r)
};
N.ready = function(e) {
    if (["interactive", "complete"].indexOf(document.readyState) !== -1) {
        setTimeout(e, 0)
    }
    return N.bind_regular(document, "DOMContentLoaded", e)
};
N.unbind = function(e, t, n) {
    var r = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : {
        capture: true
    };
    if (typeof e === "string") {
        e = document.querySelectorAll(e)
    } else if (!(e instanceof NodeList) && e.constructor !== Array) {
        e = [e]
    }
    var t = t.split(/\s+/);
    for (var a = 0; a < e.length; a++) {
        var i = e[a];
        for (var o = 0; o < t.length; o++) {
            i.removeEventListener(t[o], n, N.browser.supports_passive_events ? r : r.capture || false)
        }
    }
};
(function() {
    function e(e) {
        return function(t, n) {
            var r = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : false;
            if (r && N.matches(t, n)) {
                return t
            }
            do {
                t = t[e]
            } while (t && !N.matches(t, n));
            return t
        }
    }
    N.find_parent = e("parentNode");
    N.find_next = e("nextElementSibling");
    N.find_previous = e("previousElementSibling")
})();
N.matches = function(e, t) {
    var n = e.matches || e.matchesSelector || e.webkitMatchesSelector || e.mozMatchesSelector || e.msMatchesSelector;
    if (n) {
        return n.call(e, t)
    }
    var r = document.querySelectorAll(t);
    for (var a = 0; a < r.length; a++) {
        if (r[a] === e) {
            return true
        }
    }
    return false
};
N.format = function(e) {
    var t = _typeof(arguments[1]);
    var n = t === "string" || t === "number" ? [].slice.call(arguments, 1) : arguments[1];
    for (var r = 0; r < n.length; r++) {
        e = e.replace(RegExp("\\{" + r + "\\}", "gi"), n[r])
    }
    return e
};
N.pad = function(e, t, n) {
    var r = e;
    for (var a = 0; a < t - r.length; a++) {
        r = n + r
    }
    return r
};
N.html_escape = function(e) {
    var t = {
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&#34;",
        "'": "&#39;"
    };
    return e.toString().replace(/[&<>"']/g, function(e) {
        return t[e]
    })
};
N.render_template = function(e) {
    var t = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    var n = "\n		var parts = [];\n\n		with (context) {\n			parts.push('" + e.replace(/[\r\t\n]/g, " ").split("<%").join("	").replace(/((^|%>)[^\t]*)'/g, "$1\r").replace(/\t!=(.*?)%>/g, "',$1,'").replace(/\t=(.*?)%>/g, "',N.html_escape($1),'").split("	").join("');").split("%>").join("parts.push('").split("\r").join("\\'") + "');\n		}\n\n		return parts.join('');";
    t.N = N;
    return new Function("context", n)(t)
};
N.create_element = function(e) {
    var t = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    var n = document.createElement("div");
    n.innerHTML = N.render_template(N.strip(e), t);
    if (n.childNodes.length === 1) {
        return n.childNodes[0]
    }
    var r = document.createDocumentFragment();
    while (n.childNodes.length > 0) {
        r.appendChild(n.childNodes[0])
    }
    return r
};
N.pretty_integer = function(e) {
    if (1e9.toLocaleString().length === 10) {
        return e.toString().replace(/\B(?=(?:\d{3})+(?!\d))/g, ",")
    } else {
        return e.toLocaleString()
    }
};
N.strip = function(e) {
    return e.replace(/^\s+|\s+$/g, "")
};
N.forEach = function(e, t) {
    for (var n = 0; n < e.length; n++) {
        t(e[n])
    }
};
N.clamp = function(e, t, n) {
    return Math.max(t, Math.min(e, n))
};
N.extend = function(e, t) {
    var n = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : false;
    for (var r in t) {
        if (t.hasOwnProperty(r)) {
            if (n && e.hasOwnProperty(r)) {
                continue
            }
            e[r] = t[r]
        }
    }
};
N.keys = function(e) {
    if (Object.keys) {
        return Object.keys(e)
    }
    var t = [];
    for (var n in e) {
        if (e.hasOwnProperty(n)) {
            t.push(n)
        }
    }
    return t
};
N.inject_script = function(e, t, n, r) {
    var a = document.createElement("script");
    N.extend(a, t);
    if (e.indexOf("//") === 0) {
        e = document.location.protocol + e
    }
    a.src = e;
    var i = document.getElementsByTagName("script")[0];
    i.parentNode.insertBefore(a, i);
    if (n) {
        N.bind(a, "load", n)
    }
    if (r) {
        N.bind(a, "error", r)
    }
};
N.rate_limit = function(e, t) {
    var n = null;
    var r = null;
    return function() {
        var a = N.now();
        var i = Math.min(a - n, t);
        if (r !== null) {
            return
        }
        var o = arguments;
        r = setTimeout(function() {
            r = null;
            e.apply(null, o)
        }, i);
        n = a
    }
};
N.sgn = function(e) {
    if (e >= 0) {
        return 1
    } else {
        return -1
    }
};
N.debouncer = function(e) {
    this.delay = e;
    this.last_hit = null
};
N.debouncer.prototype.hit = function() {
    if (this.is_ready()) {
        this.last_hit = N.now()
    }
};
N.debouncer.prototype.is_ready = function() {
    if (!this.last_hit) {
        return true
    }
    return N.now() - this.last_hit > this.delay
};
N.show_message = function(e, t) {
    var n = document.createElement("div");
    n.classList.add("alert");
    n.classList.add("alert-" + t);
    n.textContent = e;
    document.querySelector("#messages").appendChild(n)
};
N.range = function(e, t) {
    var n = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 1;
    var r = [];
    if (n > 0) {
        for (var a = e; a < t; a += n) {
            r.push(a)
        }
    } else {
        for (var a = e; a > t; a += n) {
            r.push(a)
        }
    }
    return r
};
N.cached = function(e) {
    var t = {};
    return function() {
        var n = Array.prototype.join.call(arguments, "|");
        if (!(n in t)) {
            return t[n] = e.apply(null, arguments)
        }
        return t[n]
    }
};
N.now = function() {
    return +new Date
};
(function() {
    function e(e, t) {
        var n = (e & 255) >> 2;
        var r = (e & 3) << 4 | e >> 12;
        var a = (e >> 8 & 15) << 2 | (t & 255) >> 6;
        var i = t & 63;
        var o = t >> 10;
        var s = (t >> 8 & 3) << 4 | 8;
        var l = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
        var c = l[n] + l[r] + l[a] + l[i] + l[o] + l[s];
        return "data:image/gif;base64,R0lGODlh" + c + "ABAAAAAAAAACH5BAEAAAAALAEAAQABAAEAAAICRAEAOw=="
    }
    N.create_placeholder = function() {
        var t = new Image;
        t.setAttribute("src", e(200, 500));
        if (t.width === 200 && t.height === 500) {
            return N.cached(e)
        } else if (!!window.CanvasRenderingContext2D) {
            var n = document.createElement("canvas");
            return N.cached(function(e, t) {
                n.width = e;
                n.height = t;
                return n.toDataURL()
            })
        } else {
            var r = e(200, 275);
            return function(e, t) {
                return r
            }
        }
    }()
})();
N.encode_params = function(e) {
    var t = [];
    var n = N.keys(e);
    for (var r = 0; r < n.length; r++) {
        var a = n[r];
        t.push(N.format("{0}={1}", encodeURIComponent(a), encodeURIComponent(e[a])))
    }
    return t.join("&")
};
N.http = function(e) {
    var t = {
        headers: {
            "X-Requested-With": "XMLHttpRequest"
        },
        method: "GET",
        success: function s() {},
        failure: function l() {},
        csrf: true,
        xhr_properties: {},
        params: null,
        json: null
    };
    N.extend(e, t, true);
    if (e.csrf && N.options.csrf_token) {
        t.headers["X-CSRFToken"] = N.options.csrf_token
    }
    var n = new XMLHttpRequest;
    n.open(e.method, e.url, true);
    var r = N.keys(e.headers);
    for (var a = 0; a < r.length; a++) {
        var i = r[a];
        n.setRequestHeader(i, e.headers[i])
    }
    N.bind(n, "load", e.success);
    N.bind(n, "error", e.failure);
    var o = null;
    if (e.params !== null) {
        o = N.encode_params(e.params);
        n.setRequestHeader("Content-Type", "application/x-www-form-urlencoded")
    } else if (e.json !== null) {
        o = JSON.stringify(e.json);
        n.setRequestHeader("Content-Type", "application/json")
    }
    N.extend(n, e.xhr_properties);
    n.send(o);
    return n
};
N.browser = {};
N.browser.supports_passive_events = function() {
    var e = false;
    try {
        var t = Object.defineProperty({}, "passive", {
            get: function r() {
                e = true
            }
        });
        window.addEventListener("test", null, t)
    } catch (n) {}
    return e
};
N.local_storage = {};
N.local_storage.set = function(e, t) {
    localStorage.setItem(e, JSON.stringify(t))
};
N.local_storage.has = function(e) {
    return localStorage.getItem(e) !== null
};
N.local_storage.get = function(e, t) {
    if (!N.local_storage.has(e)) {
        return t
    }
    return JSON.parse(localStorage.getItem(e))
};
N.local_storage.delete = function(e) {
    localStorage.removeItem(e)
};
N.cookie_storage = {};
N.cookie_storage.set = function(e, t) {
    N.cookies.set(e, JSON.stringify(t), 24 * 60 * 60)
};
N.cookie_storage.has = function(e) {
    return N.cookies.has(e)
};
N.cookie_storage.get = function(e, t) {
    if (!N.cookie_storage.has(e)) {
        return t
    }
    return JSON.parse(N.cookies.get(e))
};
N.cookie_storage.delete = function(e) {
    N.cookies.delete(e)
};
N.memory_storage = {};
N.memory_storage.data = {};
N.memory_storage.set = function(e, t) {
    N.memory_storage.data[e] = t
};
N.memory_storage.has = function(e) {
    return e in N.memory_storage.data
};
N.memory_storage.get = function(e, t) {
    if (!N.memory_storage.has(e)) {
        return t
    }
    return N.memory_storage.data[e]
};
N.memory_storage.delete = function(e) {
    delete N.memory_storage.data[e]
};
N.storage = function() {
    try {
        localStorage.setItem("_storage_test", "test");
        if (localStorage.getItem("_storage_test") !== "test") {
            throw new Error("Storage does not actually work")
        }
        localStorage.removeItem("_storage_test");
        return N.local_storage
    } catch (e) {}
    try {
        document.cookie = "_cookie_test=test";
        if (document.cookie.indexOf("_cookie_test=test") === -1) {
            throw new Error("Cookies do not actually work")
        }
        document.cookie = "_cookie_test=test;expires=Thu, 01 Jan 1970 00:00:01 GMT";
        return N.cookie_storage
    } catch (e) {}
    return N.memory_storage
}();
N.browser = function() {
    var e = navigator.userAgent.toLowerCase();
    var t = {
        webkit: /webkit/.test(e),
        mozilla: /mozilla/.test(e) && !/(compatible|webkit)/.test(e),
        chrome: /chrome/.test(e) || /crios/.test(e),
        msie: /msie/.test(e) && !/opera/.test(e),
        edge: /edge/.test(e),
        ie11: /mozilla/.test(e) && /trident/.test(e) && /rv:11/.test(e),
        firefox: /firefox/.test(e),
        safari: /safari/.test(e) && !(/chrome/.test(e) || /crios/.test(e)),
        opera: /opera/.test(e),
        opr: /opr/.test(e),
        yandex: /yabrowser/.test(e),
        facebook: /fbav/.test(e),
        ucbrowser: /ubrowser/.test(e) || /ucbrowser/.test(e),
        android: /android/i.test(e),
        ios: /iphone|ipad|ipod/i.test(e),
        ios9: (/os 9/.test(e) || /os 10/.test(e)) && /like mac os x/.test(e),
        blackberry: /blackberry|bb/i.test(e),
        windows_phone: /windows\sphone/i.test(e),
        new_webview: /Mobile/i.test(e),
        isMobile: /Android|BlackBerry|iPhone|iPad|iPod|Opera\sMini|IEMobile/i.test(e)
    };
    t.version = t.safari ? (e.match(/.+(?:ri)[\/: ]([\d.]+)/) || [])[1] : (e.match(/.+(?:ox|me|ra|ie)[\/: ]([\d.]+)/) || [])[1];
    t.windows_version = parseInt((e.match(/.+(?:windows nt)[\/: ]([\d.]+)/) || [])[1], 10);
    t.mac = /mac os/.test(e) && !t.ios && parseInt(t.version, 10) >= 48;
    return t
}();
N.popunder = function(e, t, n) {
    this.state = {
        url: e,
        clicked_url: null,
        pdf_object: null,
        options: "toolbar=no,directories=no,scrollbars=yes,location=yes,statusbar=yes,menubar=no,resizable=1,width=" + window.screen.availWidth + ",height=" + window.screen.availHeight + ",left=0,top=0",
        window: false,
        pdf: "data:application/pdf;base64,JVBERi0xLjYNCiXi48/TDQo2IDAgb2JqDQo8PA0KL0xpbmVhcml6ZWQgMQ0KL0wgMTg2Ng0KL0ggWyA2NTUgMTI3IF0NCi9PIDgNCi9FIDEyMjkNCi9OIDENCi9UIDE2MjANCj4+DQplbmRvYmoNCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICANCnhyZWYNCjYgNg0KMDAwMDAwMDAxNyAwMDAwMCBuDQowMDAwMDAwNTg2IDAwMDAwIG4NCjAwMDAwMDA3ODIgMDAwMDAgbg0KMDAwMDAwMDk2MyAwMDAwMCBuDQowMDAwMDAxMDQzIDAwMDAwIG4NCjAwMDAwMDA2NTUgMDAwMDAgbg0KdHJhaWxlcg0KPDwNCi9TaXplIDEyDQovUHJldiAxNjEwDQovSW5mbyA1IDAgUg0KL1Jvb3QgNyAwIFINCi9JRCBbPDZlZjdhODFiZGQ2NDYwMGFmNDQ5NmQ0MzMyMjA3ZmViPjw2ZWY3YTgxYmRkNjQ2MDBhZjQ0OTZkNDMzMjIwN2ZlYj5dDQo+Pg0Kc3RhcnR4cmVmDQowDQolJUVPRg0KICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICANCjcgMCBvYmoNCjw8DQovVHlwZSAvQ2F0YWxvZw0KL1BhZ2VzIDEgMCBSDQovTmFtZXMgMiAwIFINCj4+DQplbmRvYmoNCjExIDAgb2JqDQo8PA0KL1MgMzYNCi9GaWx0ZXIgL0ZsYXRlRGVjb2RlDQovTGVuZ3RoIDM5DQo+Pg0Kc3RyZWFtDQp4nGNgYGBmYGDqZwACxv0M2AAHEpsZihkYAhjYTzEHMAAATukC1woNCmVuZHN0cmVhbQ0KZW5kb2JqDQo4IDAgb2JqDQo8PA0KL1R5cGUgL1BhZ2UNCi9Dcm9wQm94IFsgMCAwIDYxMiA3OTIgXQ0KL01lZGlhQm94IFsgMCAwIDYxMiA3OTIgXQ0KL1JvdGF0ZSAwDQovUmVzb3VyY2VzIDw8IC9FeHRHU3RhdGUgPDwgL0dTMCA5IDAgUiA+PiA+Pg0KL0NvbnRlbnRzIDEwIDAgUg0KL1BhcmVudCAxIDAgUg0KPj4NCmVuZG9iag0KOSAwIG9iag0KPDwNCi9CTSAvTm9ybWFsDQovQ0EgMQ0KL1NBIHRydWUNCi9UeXBlIC9FeHRHU3RhdGUNCi9jYSAxDQo+Pg0KZW5kb2JqDQoxMCAwIG9iag0KPDwNCi9GaWx0ZXIgL0ZsYXRlRGVjb2RlDQovTGVuZ3RoIDEwNA0KPj4NCnN0cmVhbQ0KeJwr5DJUMABCXRBlbmmkkJzLZWShYG5momdiaKgA5gBRDpephSmCAZPOQVabw5XBFa7FlQc0EQSL0rn03YMNFNKLuQz0zE0NzMxNwDbBORCTgfaBRM1NjBQsLYC6UrnSuAK5AM8iHgINCmVuZHN0cmVhbQ0KZW5kb2JqDQoxIDAgb2JqDQo8PA0KL1R5cGUgL1BhZ2VzDQovS2lkcyBbIDggMCBSIF0NCi9Db3VudCAxDQo+Pg0KZW5kb2JqDQoyIDAgb2JqDQo8PA0KL0phdmFTY3JpcHQgMyAwIFINCj4+DQplbmRvYmoNCjMgMCBvYmoNCjw8DQovTmFtZXMgWyAoZikgNCAwIFIgXQ0KPj4NCmVuZG9iag0KNCAwIG9iag0KPDwNCi9KUyAoYXBwLmFsZXJ0XCgnUGxlYXNlIHdhaXQuLidcKTspDQovUyAvSmF2YVNjcmlwdA0KPj4NCmVuZG9iag0KNSAwIG9iag0KPDwNCi9DcmVhdGlvbkRhdGUgKEQ6MjAxNjA3MjMyMzAzMTMrMDcnMDAnKQ0KL1Byb2R1Y2VyIChwb3B1bmRlcmpzLmNvbSkNCi9Nb2REYXRlIChEOjIwMTYwNzI0MDYxODI1KzAyJzAwJykNCj4+DQplbmRvYmoNCnhyZWYNCjAgNg0KMDAwMDAwMDAwMCA2NTUzNSBmDQowMDAwMDAxMjI5IDAwMDAwIG4NCjAwMDAwMDEyOTUgMDAwMDAgbg0KMDAwMDAwMTMzOSAwMDAwMCBuDQowMDAwMDAxMzg2IDAwMDAwIG4NCjAwMDAwMDE0ODIgMDAwMDAgbg0KdHJhaWxlcg0KPDwNCi9TaXplIDYNCi9JRCBbPDZlZjdhODFiZGQ2NDYwMGFmNDQ5NmQ0MzMyMjA3ZmViPjw2ZWY3YTgxYmRkNjQ2MDBhZjQ0OTZkNDMzMjIwN2ZlYj5dDQo+Pg0Kc3RhcnR4cmVmDQoxNzgNCiUlRU9GDQolta"
    };
    this._parent = self;
    this.popunder_color = t;
    this.show_callback = n || function() {};
    try {
        this._parent = top != self && typeof top.document.location.toString() === "string" ? top : self
    } catch (r) {}
    this.pdf_hack_interval = null;
    this.is_window_open_native = window.open.toString().indexOf("[native code]") !== -1;
    this.postWindowPopCalled = false;
    var a = this;
    this.bound_focus_callback = function() {
        a.focus_callback()
    }
};
N.popunder.prototype.focus_callback = function() {
    if (!N.browser.mac) {
        clearInterval(this.pdf_hack_interval)
    }
    this.focus_achieved()
};
N.popunder.prototype.focus_achieved = function() {
    if (!this.postWindowPopCalled) {
        this.postWindowPopCalled = true;
        this.postWindowPop();
        var e = this;
        this._parent.window.removeEventListener("focus", this.bound_focus_callback)
    }
};
N.popunder.prototype.postWindowPop = function() {
    this.state.pdf_object.setAttribute("data", "data:application/pdf;base64,JVBERi0xLjANCjEgMCBvYmo8PC9QYWdlcyAyIDAgUj4+ZW5kb2JqIDIgMCBvYmo8PC9LaWRzWzMgMCBSXS9Db3VudCAxPj5lbmRvYmogMyAwIG9iajw8L01lZGlhQm94WzAgMCAzIDNdPj5lbmRvYmoNCnRyYWlsZXI8PC9Sb290IDEgMCBSPj4=");
    var e = this;
    setTimeout(function() {
        e.state.pdf_object.parentNode.parentNode.removeChild(e.state.pdf_object.parentNode)
    }, 20);
    this.state.pdf_object.focus();
    try {
        this.state.window.moveTo(0, 0);
        this.state.window.resizeTo(screen.width, screen.height);
        this.state.window.location = this.state.url
    } catch (t) {}
    this.assign_location();
    this.state.clicked_url = null
};
N.popunder.prototype.popunder_init = function(e) {
    this.show_callback();
    if (this.state.clicked_url) {
        if (e.preventDefault) {
            e.preventDefault()
        } else {
            e.returnValue = false
        }
    }
    if (N.browser.chrome && !(N.browser.ios || N.browser.android || N.browser.blackberry || N.browser.windows_phone || N.browser.ucbrowser)) {
        var t = function l() {
            return N.browser.chrome && !N.browser.yandex && !N.browser.edge && N.browser.version && N.browser.version.split(".")[0] && parseInt(N.browser.version.split(".")[0]) >= 41 && !!navigator.mimeTypes["application/pdf"]
        };
        if (t()) {
            this.postWindowPopCalled = false;
            var n = e.target || e.srcElement;
            var r = Math.floor(Math.random() * 1e3 + 1).toString();
            try {
                this.state.window = this._parent.window.open("about:blank", r, "directories=0,toolbar=0,scrollbars=1,location=0,statusbar=0,menubar=0,resizable=1,width=1,height=1,screenX=19999,screenY=19999");
                this.state.window.document.write("<html><head><script>window.a={};window.a.b=function(){window.resizeTo(1,0);window.moveTo(19999,19999);};window.a.b();window.open('', '_self');</script></head><body style='background:" + this.popunder_color + "'></body></html>");
                if (!N.browser.mac) {
                    this.clear_window_opener()
                }
            } catch (a) {}
            this.pdf_hack_interval = null;
            var i = document.createElement("div");
            i.style = "visibility:hidden;width:0;height:0;opacity:0;position:absolute;top:100%;left:0;pointer-events:none;overflow:hidden;";
            this.state.pdf_object = document.createElement("object");
            this.state.pdf_object.setAttribute("data", this.state.pdf);
            i.appendChild(this.state.pdf_object);
            if (window.document.body) {
                window.document.body.appendChild(i)
            }
            var o = this;
            if (!N.browser.mac) {
                this.pdf_hack_interval = setInterval(function() {
                    if (o._parent.window.document.hasFocus()) {
                        clearInterval(o.pdf_hack_interval);
                        o.focus_achieved()
                    }
                }, 20)
            }
            this._parent.window.addEventListener("focus", this.bound_focus_callback);
            setTimeout(function() {
                if (!N.browser.mac) {
                    clearInterval(o.pdf_hack_interval)
                }
                o.focus_achieved()
            }, 3e3)
        } else {
            this.is_window_open_native ? this.open_window_type1(e) : this.open_window_with_mouse_event(e);
            this.clear_window_opener();
            this.assign_location();
            this.state.clicked_url = null
        }
        return true
    } else if (N.browser.android || N.browser.blackberry || N.browser.windows_phone) {
        if (N.browser.facebook) {
            this.state.window = window.open(this.state.url);
            this.clear_window_opener()
        } else if (N.browser.windows_phone) {
            location.assign(this.state.url)
        } else {
            try {
                this.is_window_open_native ? this.open_window_with_random_name() : this.open_window_with_mouse_event(e)
            } catch (s) {}
            gc_click(e);
            this.clear_window_opener();
            this.assign_location()
        }
    } else if (N.browser.ios) {
        if (N.browser.ucbrowser) {
            if (typeof e !== "undefined") {
                if (e.preventDefault) {
                    e.preventDefault()
                } else {
                    e.returnValue = false
                }
            }
            safe_open_window(this.state.url, "", "", window.document)
        } else {
            if (N.browser.facebook) {
                this.state.window = window.open(this.state.url);
                this.clear_window_opener()
            } else {
                safe_open_window(this.state.url, "", "", window.document);
                this.state.window = false;
                this.assign_location()
            }
            gc_click(e)
        }
    } else {
        this.is_window_open_native ? N.browser.opr || N.browser.ucbrowser ? this.open_window_type1(e) : this.open_window_with_random_name_and_click(e) : this.open_window_with_mouse_event(e);
        this.assign_location();
        if (this.state.window) {
            this.blur_parent_window();
            this.clear_window_opener()
        }
        this.state.window = false
    }
    this.state.clicked_url = null
};
N.popunder.prototype.attach_to_document = function() {
    var e = this;
    if (document.addEventListener) {
        N.bind_once(document, "click", function(t) {
            e.state.clicked_url = closest_link_href(t.target);
            e.popunder_init(t)
        }, true)
    } else if (document.attachEvent) {
        var t = function r(t) {
            document.detachEvent("onclick", r);
            var n = N.browser.msie ? t.srcElement : t.target ? t.target : "";
            e.state.clicked_url = closest_link_href(t.target);
            e.popunder_init(t)
        };
        document.attachEvent("onclick", t)
    } else {
        var n = setInterval(function() {
            if (typeof document.body !== "undefined" && document.body) {
                document.body.onclick = function(t) {
                    var n = N.browser.msie ? t.srcElement : t.target ? t.target : "";
                    e.state.clicked_url = closest_link_href(t.target);
                    e.popunder_init(t)
                };
                clearInterval(n)
            }
        }, 10)
    }
};
N.popunder.prototype.open_window_type1 = function(e) {
    this.state.window = window.open(this.state.url, N.browser.opr && N.browser.windows_version >= 10 ? "" : "window_" + Math.ceil(Math.random() * 1e5));
    if (e && !N.browser.chrome) {
        e.target.click()
    }
};
N.popunder.prototype.open_window_with_random_name = function(e) {
    this.state.window = window.open(this.state.url, "window_" + Math.ceil(Math.random() * 1e5))
};
N.popunder.prototype.open_window_with_random_name_and_click = function(e) {
    this.state.window = this._parent.window.open(this.state.url, "window_" + Math.ceil(Math.random() * 1e5), this.state.options);
    if (!N.browser.firefox && !N.browser.safari) gc_click(e)
};
N.popunder.prototype.clear_window_opener = function() {
    if (this.state.window) {
        try {
            this.state.window.opener = null
        } catch (e) {}
    }
};
N.popunder.prototype.assign_location = function() {
    if (this.state.clicked_url) {
        this._parent.window.location.assign(this.state.clicked_url)
    }
};
N.popunder.prototype.blur_parent_window = function() {
    try {
        this.state.window.blur();
        if (window != window.top) {
            window.top.focus()
        } else {
            this.state.window.opener.window.focus()
        }
        if (!N.browser.msie) {
            window.self.window.blur()
        }
        window.focus();
        if (N.browser.safari) {
            if (N.browser.mac) {
                var e = window.open("about:blank");
                e.focus();
                e.close()
            } else {
                setTimeout("window.focus()", 500)
            }
        }
        if (N.browser.firefox) {
            this.state.window.open("about:blank").close()
        }
    } catch (t) {}
};
N.popunder.prototype.open_window_with_mouse_event = function(e) {
    var t = document.createEvent("MouseEvents");
    var n = document.createElement("a");
    n.href = this.state.url;
    n.target = "_blank";
    t.initMouseEvent("click", true, true, window, N.browser.firefox ? 0 : true, 0, 0, 0, 0, false, false, false, false, 0, null);
    n.dispatchEvent(t);
    if (!N.browser.chrome) {
        if (e && e.target && e.target.click) {
            e.target.click()
        } else {
            click_fg(e)
        }
    }
};

function safe_open_window(e, t, n, r) {
    if ("" === t || null == t) {
        t = "new_popup_window_" + (new Date).getTime()
    }
    var a = window.document.createElement("iframe");
    a.style.display = "none";
    r.body.appendChild(a);
    var i = a.contentWindow.document,
        o = "newWin_" + (new Date).getTime(),
        s = i.createElement("script");
    s.type = "text/javascript";
    s.text = ["window.top = null;", "window.frameElement = null;", "var newWin = window.open('" + e.replace(/\'/g, "\\'") + "', '" + t + "', '" + n + "');", "window.parent." + o + " = newWin;", "window.parent = null;", "newWin.opener = null;"].join("");
    i.body.appendChild(s);
    r.body.removeChild(a)
}

function gc_click(e) {
    if (!N.browser.chrome && !(N.browser.android && N.browser.safari && !N.browser.chrome && !N.browser.new_webview) && !closest_link_href(e.target)) {
        e.target.click && !N.browser.isMobile ? e.target.click() : click_fg(e)
    }
}

function click_fg(e) {
    var t;
    if (e.touches && !(N.browser.ios && N.browser.safari)) {
        t = N.browser.android && N.browser.firefox ? "touchend" : N.browser.android && N.browser.safari ? "touchstart" : N.browser.android && N.browser.chrome ? "click" : "touchend"
    } else {
        t = "click"
    }
    var n = document.createEvent("MouseEvents");
    n.initEvent(t, true, true);
    e.target.dispatchEvent(n)
}

function closest_link_href(e) {
    var t = N.find_parent(e, "a");
    return e.tagName.toLowerCase() === "a" && e.href.toString().indexOf("#") == -1 && e.href.indexOf("javascript:") == -1 || t && t.href.toString().indexOf("#") == -1 && t.href.indexOf("javascript:") == -1 ? e.href ? e.href : t.href : null
}
N.install_theme_previewer = function() {
    N.ready(function() {
        var e = document.querySelector("html");
        var t = document.querySelector("#id_theme");
        if (!t) {
            return
        }
        N.bind(t, "change", function() {
            var t = e.classList;
            for (var n = 0; n < t.length; n++) {
                if (t[n].indexOf("theme-") !== -1) {
                    t.remove(t[n])
                }
            }
            t.add("theme-" + this.value.toLowerCase())
        })
    })
};
N.install_lazy_loader = function() {
    var e = document.querySelectorAll(".lazyload");
    new N.lazy_loader(e)
};
N.lazy_loader = function(e) {
    for (var t = 0; t < e.length; t++) {
        var n = e[t];
        var r = N.create_placeholder(+n.getAttribute("width"), +n.getAttribute("height"));
        n.setAttribute("src", r)
    }
    this.$elements = [].slice.call(e);
    this.$elements.reverse();
    var a = this;
    this.scroll_event = N.bind(window, "scroll", N.rate_limit(function() {
        a.load_visible_images()
    }, 200));
    N.bind(window, "load", function() {
        a.load_visible_images()
    });
    N.bind(document.body, "load", function(e) {
        try {
            var t = e.target
        } catch (n) {
            return
        }
        if (t.tagName.toLowerCase() !== "img") {
            return
        }
        if (t.src.indexOf("data:") !== -1) {
            return
        }
        if (!t.classList.contains("lazyload")) {
            return
        }
        t.classList.remove("lazyload")
    }, {
        capture: true
    });
    this.load_visible_images()
};
N.lazy_loader.prototype.in_viewport = function(e, t) {
    var n = e.getBoundingClientRect();
    return n.bottom >= -t && n.top <= window.innerHeight + t
};
N.lazy_loader.prototype.load_visible_images = function() {
    if (!this.$elements.length) {
        N.unbind(window, "scroll", this.scroll_event);
        return
    }
    var e = false;
    var t = window.innerHeight / 2;
    for (var n = this.$elements.length - 1; n >= 0; n--) {
        var r = this.$elements[n];
        if (!this.in_viewport(r, t)) {
            if (!e) {
                continue
            } else {
                break
            }
        }
        e = true;
        this.$elements.splice(n, 1);
        r.src = r.getAttribute("data-src")
    }
};
N.install_frame_buster = function() {
    return;
    if (["localhost", "nhentai.net", "127.0.0.1", "196.25.255.251"].indexOf(window.location.hostname) !== -1) {
        return
    }
    document.body.style = "display: none";
    window.location = "https://nhentai.net" + window.location.pathname + window.location.search + window.location.hash
};
N.reader = function(e) {
    N.extend(this, e);
    this.num_pages = this.gallery.images.pages.length;
    this.gallery_url = N.format("/g/{0}/", this.gallery.id);
    this.current_page = null;
    this.$image_container = document.querySelector("#image-container");
    this.apply_settings();
    this.install_scroller();
    this.install_link_catcher();
    this.install_image_navigation();
    this.image_cache = {};
    this.preload_queue = [];
    this.direction = 1;
    this.get_image(this.start_page, document.querySelector("#image-container img"));
    var t = this;
    N.bind(window, "popstate", function(e) {
        if (e.state && e.state.page) {
            t.set_page(e.state.page, false)
        }
    })
};
N.reader.prototype.update_direction = function(e, t) {
    if (e + 1 === t) {
        this.direction = Math.min(3, this.direction + 1)
    } else if (e - 1 === t) {
        this.direction = Math.max(-3, this.direction - 1)
    }
    console.log("Direction is now", this.direction)
};
N.reader.prototype.maybe_preload = function() {
    var e = this.get_settings().preload;
    var t = [];
    if (this.direction >= 0) {
        var n = Math.min(this.current_page + 1, this.num_pages);
        var r = Math.min(this.num_pages, this.current_page + e) + 1;
        var a = 1
    } else {
        var n = Math.max(1, this.current_page - 1);
        var r = Math.max(1, this.current_page - e) - 1;
        var a = -1
    }
    var t = N.range(n, r, a);
    this.preload_pages(t)
};
N.reader.prototype.preload_pages = function(e) {
    if (!e.length) {
        return
    }
    var t = this;
    if (this.preload_timer) {
        clearTimeout(this.preload_timer);
        this.preload_timer = null
    }
    this.preload_timer = setTimeout(function() {
        do {
            var n = e[0];
            e.shift()
        } while (e.length && n in t.image_cache);
        console.log("Preloading page", n);
        var r = t.get_image(n);
        N.bind(r.image, "load", function() {
            t.preload_pages(e)
        })
    }, 100)
};
N.reader.prototype.apply_settings = function() {
    var e = this.get_settings();
    this.$image_container.className = e.image_scaling;
    if (e.show_navbar) {
        document.documentElement.classList.remove("nav-hidden")
    } else {
        document.documentElement.classList.add("nav-hidden")
    }
};
N.reader.prototype.get_settings = function(e) {
    return N.storage.get("settings", {
        reader: {
            preload: 3,
            turning_behavior: "right",
            image_scaling: "fit-horizontally",
            show_navbar: true,
            scroll_on_turn: true
        }
    }).reader
};
N.reader.prototype.get_page_url = function(e) {
    return N.format("/g/{0}/{1}/", this.gallery.id, e)
};
N.reader.prototype.get_extension = function(e) {
    return {
        j: "jpg",
        p: "png",
        g: "gif"
    }[this.gallery.images.pages[e - 1].t]
};
N.reader.prototype.get_image_url = function(e) {
    return N.format("{0}galleries/{1}/{2}.{3}", this.media_url, this.gallery.media_id, e, this.get_extension(e))
};
N.reader.prototype.get_thumbnail_url = function(e) {
    return N.format("{0}galleries/{1}/{2}t.{3}", this.media_url, this.gallery.media_id, e, this.get_extension(e))
};
N.reader.prototype.get_image = function(e, t) {
    if (!(e in this.image_cache)) {
        if (!t) {
            t = new Image;
            t.src = this.get_image_url(e)
        }
        this.image_cache[e] = {
            image: t,
            loaded: false
        };
        t.width = this.gallery.images.pages[e - 1].w;
        t.height = this.gallery.images.pages[e - 1].h;
        var n = this;
        N.bind(t, "load", function() {
            n.image_cache[e].loaded = true;
            if (n.current_page === e) {
                n.maybe_preload()
            }
        })
    }
    return this.image_cache[e]
};
N.reader.prototype.set_page = function(e, t, n) {
    if (e === this.current_page) {
        return
    }
    this.update_direction(this.current_page, e);
    console.debug("Switching to page", e);
    this.current_page = e;
    this.update_pagination(e);
    var r = document.querySelector("#image-container img");
    var a = this.get_image(e);
    if (r !== a.image) {
        r.parentNode.appendChild(a.image);
        r.parentNode.removeChild(r)
    }
    if (a.loaded) {
        this.maybe_preload()
    }
    if (t && history.pushState) {
        history.pushState({
            page: e
        }, document.title, this.get_page_url(e));
        window.ga("send", "pageview", window.location.pathname)
    }
    if (this.get_settings().scroll_on_turn) {
        this.$image_container.scrollIntoView()
    }
};
N.reader.prototype.previous_page = function() {
    this.set_page(Math.max(1, this.current_page - 1), true)
};
N.reader.prototype.next_page = function() {
    this.set_page(Math.min(this.current_page + 1, this.num_pages), true)
};
N.reader.prototype.update_pagination = function(e) {
    this.$image_container.querySelector("a").href = e < this.num_pages ? this.get_page_url(e + 1) : this.gallery_url;
    document.title = document.title.replace(/Page (\d+) /, N.format("Page {0} ", e));
    var t = N.render_template('\n		<% if (page > 1) { %>\n				<a href="<%= r.get_page_url(1) %>" class="first"><i class="fa fa-chevron-left"></i><i class="fa fa-chevron-left"></i></a>\n				<a href="<%= r.get_page_url(page - 1) %>" class="previous"><i class="fa fa-chevron-left"></i></a>\n		<% } else { %>\n				<a class="first invisible"><i class="fa fa-chevron-left"></i><i class="fa fa-chevron-left"></i></a>\n				<a class="previous invisible"><i class="fa fa-chevron-left"></i></a>\n		<% } %>\n\n		<span class="page-number"><span class="current"><%= page %></span> <span class="divider">of</span> <span class="num-pages"><%= r.num_pages %></span></span>\n\n		<% if (page < r.num_pages) { %>\n				<a href="<%= r.get_page_url(page + 1) %>" class="next"><i class="fa fa-chevron-right"></i></a>\n				<a href="<%= r.get_page_url(r.num_pages) %>" class="last"><i class="fa fa-chevron-right"></i><i class="fa fa-chevron-right"></i></a>\n		<% } else { %>\n				<a class="next invisible"><i class="fa fa-chevron-right"></i></a>\n				<a class="last invisible"><i class="fa fa-chevron-right"></i><i class="fa fa-chevron-right"></i></a>\n		<% } %>\n	', {
        r: this,
        page: e
    });
    document.querySelector("#pagination-page-bottom").innerHTML = t;
    document.querySelector("#pagination-page-top").innerHTML = t
};
N.reader.prototype.install_scroller = function() {
    var e = this;
    var t = null;
    N.bind(document, "keydown", function(n) {
        if (n.target.tagName.toLowerCase() === "input" || n.metaKey || n.ctrlKey || n.shiftKey || n.altKey) {
            return
        }
        if (t) {
            clearInterval(t);
            t = null
        }
        var r = true;
        switch (n.which) {
            case N.key.S:
            case N.key.DOWN_ARROW:
                t = setInterval(function() {
                    window.scrollBy(0, 5)
                }, 5);
                break;
            case N.key.W:
            case N.key.UP_ARROW:
                t = setInterval(function() {
                    window.scrollBy(0, -5)
                }, 5);
                break;
            case N.key.A:
            case N.key.LEFT_ARROW:
                e.previous_page();
                break;
            case N.key.D:
            case N.key.RIGHT_ARROW:
                e.next_page();
                break;
            default:
                r = false;
                break
        }
        if (r) {
            n.preventDefault()
        }
    });
    N.bind(document, "keyup visibilitychange", function() {
        if (t) {
            clearInterval(t);
            t = null
        }
    })
};
N.reader.prototype.install_link_catcher = function() {
    var e = this;
    N.bind(".pagination", "a", "click", function(t) {
        var n = this.href.match(new RegExp("/g/\\d+/(\\d+)"));
        if (n) {
            t.preventDefault();
            e.set_page(parseInt(n[1], 10), true)
        }
    }, true)
};
N.reader.prototype.install_image_navigation = function() {
    var e = this;
    var t = new N.debouncer(500);
    N.bind("#image-container", "img", "click", function(n) {
        n.preventDefault();
        if (!t.is_ready()) {
            return
        }
        t.hit();
        var r = e.get_settings().turning_behavior;
        var a;
        if (typeof n.offsetX === "undefined") {
            a = n.pageX - (this.getBoundingClientRect().left - document.body.getBoundingClientRect().left)
        } else {
            a = n.offsetX
        }
        var i = a / this.width;
        if (r === "both" || r === "left" && i < .6 || r === "right" && i > .4) {
            if (e.current_page === e.num_pages) {
                window.location = e.gallery_url
            } else {
                e.next_page()
            }
        } else {
            e.previous_page()
        }
    })
};
N.reader.prototype.install_settings_button = function() {
    var e = this;
    var t = document.querySelector(".reader-settings");
    N.bind(t, "click", function() {
        var t = N.create_element('\n			<label>Image Preloading <select id="preload">\n				<option value="0">Disabled</option>\n				<option value="1">1 page</option>\n				<option value="2">2 pages</option>\n				<option value="3">3 pages</option>\n				<option value="4">4 pages</option>\n				<option value="5">5 pages</option>\n			</select></label>\n\n			<label>Page Turning <select id="turning_behavior">\n				<option value="left">Left half</option>\n				<option value="right">Right half</option>\n				<option value="both">Entire image</option>\n			</select></label>\n\n			<label>Image Scaling <select id="image_scaling">\n				<option value="fit-horizontal">Fit horizontally</option>\n				<option value="fit-both">Fit on screen</option>\n				<option value="fit-none">Disabled</option>\n			</select></label>\n\n			<label>Navigation Bar <select id="show_navbar">\n				<option value="false">Hide</option>\n				<option value="true">Show</option>\n			</select></label>\n\n			<label>Scroll on Page Turn <select id="scroll_on_turn">\n				<option value="true">Top of image</option>\n				<option value="false">Don\'t scroll</option>\n			</select></label>\n		');
        var n = e.get_settings();
        for (var r = 0, a = N.keys(n); r < a.length; r++) {
            var i = a[r];
            t.getElementById(i).value = n[i]
        }
        var o = new N.modal("Reader Settings", t, [{
            type: "primary",
            name: "Save",
            callback: function s(t, n) {
                var r = {};
                var a = n.$wrapper.querySelectorAll("select");
                for (var i = 0; i < a.length; i++) {
                    r[a[i].id] = a[i].value
                }
                r.preload = Number(r.preload);
                r.show_navbar = r.show_navbar === "true";
                r.scroll_on_turn = r.scroll_on_turn === "true";
                var o = N.storage.get("settings", {
                    storage: {}
                });
                o.reader = r;
                N.storage.set("settings", o);
                e.apply_settings();
                n.close()
            }
        }, {
            type: "secondary",
            name: "Cancel",
            callback: function l(t, n) {
                e.apply_settings();
                n.close()
            }
        }]);
        o.show()
    })
};
N.relative_time = function(e) {
    var t = new Date;
    var e = new Date(e);
    var n = (t - e) / 1e3;

    function r(e, t) {
        var e = Math.floor(e);
        if (e == 1) {
            return N.format("{0} {1} ago", N.pretty_integer(e), t)
        } else {
            return N.format("{0} {1}s ago", N.pretty_integer(e), t)
        }
    }
    if (n < 60) {
        return r(n, "second")
    } else if (n / 60 < 60) {
        return r(n / 60, "minute")
    } else if (n / 60 / 60 < 24) {
        return r(n / 60 / 60, "hour")
    } else if (n / 60 / 60 / 24 < 7) {
        return r(n / 60 / 60 / 24, "day")
    } else if (n / 60 / 60 / 24 <= 30) {
        return r(n / 60 / 60 / 24 / 7, "week")
    } else if (n / 60 / 60 / 24 / 31 < 12) {
        return r(n / 60 / 60 / 24 / 30, "month")
    } else {
        return r(n / 60 / 60 / 24 / 365, "year")
    }
};
N.update_times = function() {
    var e = 60 * 1e3;
    var t = document.querySelectorAll("time[datetime]");
    for (var n = 0; n < t.length; n++) {
        var r = t[n];
        var a = N.relative_time(r.getAttribute("datetime"));
        if (r.textContent !== a) {
            r.textContent = a
        }
        if (a.indexOf("second") !== -1) {
            e = 1e3
        }
    }
    return e
};
N.install_relative_time = function() {
    N.ready(function() {
        var e = function t() {
            var e = N.update_times();
            setTimeout(t, e)
        };
        e()
    })
};
N.tag = function(e, t, n, r, a) {
    var i = arguments.length > 5 && arguments[5] !== undefined ? arguments[5] : false;
    this.id = e;
    this.name = t;
    this.type = n;
    this.url = r;
    this.count = a;
    this.created = i
};
N.tag.prototype.as_object = function() {
    return {
        id: this.id,
        name: this.name,
        type: this.type
    }
};
N.tag.prototype.as_element = function() {
    var e = document.createElement("a");
    e.href = this.url;
    e.classList.add("tag");
    e.classList.add("tag-" + this.id);
    var t = document.createElement("span");
    t.textContent = this.name;
    e.appendChild(t);
    e.appendChild(document.createTextNode(" "));
    var n = document.createElement("span");
    n.classList.add("count");
    if (this.created) {
        n.textContent = "(create)";
        e.classList.add("tag-created")
    } else {
        n.textContent = "(" + N.pretty_integer(this.count) + ")"
    }
    e.appendChild(n);
    e.tag = this;
    return e
};
N.gallery = function(e) {
    for (var t = 0; t < e.tags.length; t++) {
        var n = e.tags[t];
        e.tags[t] = new N.tag(n.id, n.name, n.type, n.url, n.count)
    }
    N.extend(this, e);
    this.editing = false
};
N.gallery.prototype.get_url = function(e) {
    return N.format("/g/{0}/{1}", this.id, e)
};
N.gallery.prototype.toggle_favorite = function() {
    document.querySelector("#favorite").disabled = true;
    N.http({
        method: "POST",
        url: this.get_url("favorite"),
        success: function e() {
            var e = JSON.parse(this.response);
            var t = document.querySelector("#favorite i.fa");
            document.querySelector("#favorite .count").textContent = e.count;
            document.querySelector("#favorite .text").textContent = e.favorited ? "Unfavorite" : "Favorite";
            document.querySelector("#favorite").disabled = false;
            t.classList.toggle("fa-heart");
            t.classList.toggle("fa-heart-o")
        }
    })
};
N.gallery.prototype.download_zipfile = function() {
    var e = [];
    var t = this.images.pages.toString().length;
    for (var n = 0; n < this.images.pages.length; n++) {
        var r = N.pad((n + 1).toString(), t, "0");
        var a = {
            j: "jpg",
            p: "png",
            g: "gif"
        }[this.images.pages[n].t];
        var i = N.format("//i.nhentai.net/galleries/{0}/{1}.{2}", this.media_id, n + 1, a);
        e.push([N.format("{0}.{1}", r, a), i])
    }
    var o = new N.zipfile(this.title.pretty + ".zip", e);
    o.done = function() {
        o.download()
    };
    var s = document.querySelector("#download");
    o.progress = function(e, t) {
        s.textContent = N.format("Downloaded {0} of {1}: {2}%", e, t, (100 * e / t).toFixed(2))
    }
};
N.gallery.prototype.toggle_edit = function() {
    if (this.editing) {
        this.editing = false;
        document.querySelector("#edit .text").textContent = "Edit";
        document.querySelector("#edit").disabled = true;
        this.end_edit()
    } else {
        this.editing = true;
        document.querySelector("#edit .text").textContent = "Save";
        this.begin_edit()
    }
};
N.gallery.prototype.begin_edit = function() {
    var e = ["parody", "character", "tag", "artist", "group", "language", "category"];
    var t = {
        tag: [],
        artist: [],
        parody: [],
        character: [],
        group: [],
        language: [],
        category: []
    };
    var n = {
        tag: "Tags",
        artist: "Artists",
        parody: "Parodies",
        character: "Characters",
        group: "Groups",
        language: "Languages",
        category: "Categories"
    };
    for (var r = 0; r < this.tags.length; r++) {
        var a = this.tags[r];
        t[a.type].push(a)
    }
    this.editors = [];
    document.querySelector("#tags").innerHTML = "";
    for (var r = 0; r < e.length; r++) {
        var i = new N.tag_editor(e[r], t[e[r]], true);
        this.editors.push(i);
        i.$wrapper.querySelector(".name").textContent = n[e[r]] + ":";
        document.querySelector("#tags").appendChild(i.$wrapper);
        i.begin_edit()
    }
};
N.gallery.prototype.end_edit = function() {
    var e = [];
    var t = [];
    var n = [];
    for (var r = 0; r < this.editors.length; r++) {
        var a = this.editors[r];
        a.end_edit();
        var i = a.state();
        for (var o = 0; o < i.added.length; o++) {
            var s = i.added[o];
            if (s.id.toString().indexOf("new-") !== -1) {
                t.push({
                    name: s.name,
                    type: s.type
                })
            } else {
                e.push(s.id)
            }
        }
        for (var o = 0; o < i.removed.length; o++) {
            var s = i.removed[o];
            if (s.id.toString().indexOf("new-") === -1) {
                n.push(s.id)
            }
        }
    }
    N.http({
        url: this.get_url("edit"),
        method: "POST",
        json: {
            added_tags: e,
            removed_tags: n,
            created_tags: t
        },
        success: function l() {
            debugger;
            var e = JSON.parse(this.response);
            if (e.error) {
                N.show_message("An error has occured: " + e.error, "danger")
            } else {
                N.show_message("Your edit has been saved and will be approved shortly", "success")
            }
        },
        failure: function c(e) {
            var t = JSON.parse(this.response);
            N.show_message("An error has occured: " + t.error, "danger")
        }
    })
};
N.tag_autocomplete = function(e, t, n) {
    var r = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : {};
    this.tag = e;
    this.type = t;
    this.editor = n;
    this.exclude = r;
    this.$wrapper = N.create_element('\n		<div class="tag-autocomplete">\n			<div class="autocomplete-wrapper">\n				<input type="text" class="tag tag-input" placeholder="enter a tag name" autocapitalize="none" />\n				<ul class="dropdown"></ul>\n			</div>\n\n			<div class="tag-wrapper"></div>\n		</div>\n	');
    this.$autocomplete_wrapper = this.$wrapper.querySelector(".autocomplete-wrapper");
    this.$tag_wrapper = this.$wrapper.querySelector(".tag-wrapper");
    this.$input = this.$autocomplete_wrapper.querySelector("input");
    this.$dropdown = this.$autocomplete_wrapper.querySelector("ul");
    this.install_handlers()
};
N.tag_autocomplete.prototype.install_handlers = function() {
    var e = this;
    N.bind(this.$input, "keydown", function(t) {
        var n = e.$dropdown.querySelector("li.active");
        var r = e.$dropdown.querySelector("li");
        var a = !!n;
        n = n || r;
        if (t.which === N.key.ESCAPE || this.value === "" && t.which === N.key.BACKSPACE) {
            t.preventDefault();
            this.focus();
            e.remove()
        } else if (t.which === N.key.UP_ARROW) {
            n.classList.remove("active");
            (N.find_previous(n, "li:not(.disabled)") || n).classList.add("active")
        } else if (t.which === N.key.DOWN_ARROW) {
            if (!a) {
                n.classList.add("active")
            } else {
                n.classList.remove("active");
                (N.find_next(n, "li:not(.disabled)") || n).classList.add("active")
            }
        } else if (t.which === N.key.ENTER) {
            if (e.$dropdown.children.length === 1) {
                n = e.$dropdown.children[0]
            } else if (!a) {
                return
            }
            var i = n.querySelector("a");
            e.select_tag(i)
        }
    });
    N.bind(this.$dropdown, "li, a", "click", function(t) {
        var n = N.matches(this, "a") ? this : this.querySelector("a");
        e.select_tag(n);
        t.preventDefault()
    });
    N.bind(this.$dropdown, "li:not(.disabled)", "hover", function(t) {
        var n = e.$dropdown.querySelector("li.active");
        if (n === this) {
            return
        } else if (n) {
            n.classList.remove("active")
        }
        this.classList.add("active")
    });
    N.bind(this.$tag_wrapper, ".tag", "click", function(t) {
        var n = e.$tag_wrapper.children[0];
        var r = "";
        if (n) {
            r = n.tag.name
        }
        e.$autocomplete_wrapper.classList.remove("hidden");
        e.$tag_wrapper.innerHTML = "";
        e.$input.value = r;
        e.$input.focus();
        t.preventDefault();
        t.stopPropagation()
    }, {
        capture: true
    });
    this.old_value = "";
    N.bind(this.$input, "keyup", function(t) {
        if (this.value !== e.old_value) {
            e.show_autocomplete(this.value);
            e.old_value = this.value
        }
    });
    setTimeout(function() {
        N.bind(document, "click", function(t) {
            if (e.$autocomplete_wrapper.classList.contains("hidden")) {
                return
            }
            if (e.$wrapper.contains(t.target)) {
                return
            }
            if (e.$wrapper === t.target) {
                return
            }
            e.remove()
        }, {
            capture: false
        })
    }, 100)
};
N.tag_autocomplete.prototype.remove = function() {
    this.editor.added_tags.splice(this.editor.added_tags.indexOf(this.tag), 1);
    this.$wrapper.parentNode.removeChild(this.$wrapper)
};
N.tag_autocomplete.prototype.select_tag = function(e) {
    N.extend(this.tag, e.tag);
    e.classList.add("tag-added");
    this.$tag_wrapper.appendChild(e);
    this.$autocomplete_wrapper.classList.add("hidden")
};
N.tag_autocomplete.prototype.show_autocomplete = function(e) {
    var t = this;
    N.http({
        url: "/api/autocomplete",
        method: "POST",
        params: {
            name: e,
            type: this.type
        },
        success: function n() {
            t.$dropdown.innerHTML = "";
            var n = JSON.parse(this.response);
            var r = false;
            for (var a = 0; a < n.result.length; a++) {
                var i = n.result[a];
                if (t.exclude[i.id]) {
                    continue
                }
                r = true;
                var o = new N.tag(i.id, i.name, i.type, i.url, i.count);
                var s = document.createElement("li");
                s.appendChild(o.as_element());
                t.$dropdown.appendChild(s)
            }
            if (N.strip(e)) {
                var s = document.createElement("li");
                if (t.editor.create) {
                    t.tag.name = N.strip(e);
                    t.tag.created = true;
                    s.appendChild(t.tag.as_element())
                } else if (!r) {
                    s.classList.add("disabled");
                    s.appendChild(document.createTextNode("no results"))
                }
                t.$dropdown.appendChild(s)
            }
        }
    })
};
N.tag_editor = function(e) {
    var t = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : [];
    var n = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : false;
    this.type = e;
    this.tags = {};
    this.create = n;
    this.removed_tags = {};
    this.added_tags = [];
    this.autocomplete_excluded_tags = {};
    this.new_tag_counter = 0;
    this.$wrapper = N.create_element('\n		<div class="tag-container field-name">\n			<span class="name"></span>\n			<span class="tags"></span>\n		</div>\n	', {
        type: this.type
    });
    for (var r = 0; r < t.length; r++) {
        this.tags[t[r].id] = t[r];
        this.$wrapper.appendChild(t[r].as_element())
    }
    this.editing = false;
    this.recompute_excluded_tags()
};
N.tag_editor.prototype.recompute_excluded_tags = function() {
    var e = N.keys(this.autocomplete_excluded_tags);
    for (var t = 0; t < e.length; t++) {
        delete this.autocomplete_excluded_tags[e[t]]
    }
    var n = N.keys(this.tags);
    Array.prototype.push.apply(n, this.added_tags.map(function(e) {
        return e.id
    }));
    Array.prototype.push.apply(n, N.keys(this.removed_tags));
    for (var t = 0; t < n.length; t++) {
        this.autocomplete_excluded_tags[n[t]] = true
    }
};
N.tag_editor.prototype.begin_edit = function() {
    if (this.editing) {
        throw new Error("Already editing")
    }
    this.editing = true;
    var e = this;
    this.tag_click_callback = N.bind(this.$wrapper, ".tag-container > .tag", "click", function(t) {
        if (this.classList.contains("tag-new") || this.classList.contains("tag-added")) {
            return
        }
        t.preventDefault();
        if (this.classList.contains("tag-deleted")) {
            delete e.removed_tags[this.tag.id]
        } else {
            e.removed_tags[this.tag.id] = e.tags[this.tag.id]
        }
        this.classList.toggle("tag-deleted");
        e.recompute_excluded_tags()
    });
    var t = N.create_element('<a class="tag tag-new">+</a>');
    N.bind(t, "click", function() {
        var t = new N.tag("new-" + e.new_tag_counter++, "", e.type, "#", 0);
        e.added_tags.push(t);
        e.recompute_excluded_tags();
        var n = new N.tag_autocomplete(t, e.type, e, e.autocomplete_excluded_tags);
        this.parentNode.insertBefore(n.$wrapper, this);
        n.$input.focus();
        n.show_autocomplete("")
    });
    this.$wrapper.appendChild(t)
};
N.tag_editor.prototype.end_edit = function() {
    if (!this.editing) {
        throw new Error("Not editing")
    }
    this.editing = false;
    var e = this.$wrapper.querySelectorAll(".tag-new");
    for (var t = 0; t < e.length; t++) {
        e[t].parentNode.removeChild(e[t])
    }
};
N.tag_editor.prototype.state = function() {
    var e = [];
    for (var t = 0, n = N.keys(this.removed_tags); t < n.length; t++) {
        e.push(this.removed_tags[n[t]])
    }
    return {
        added: this.added_tags,
        removed: e
    }
};
N.install_menu_events = function() {
    var e = document.querySelector(".dropdown-menu");
    var t = document.querySelector("#dropdown");
    if (!t) {
        return
    }

    function n() {
        e.classList.toggle("open");
        t.querySelector("i").classList.toggle("fa-chevron-down");
        t.querySelector("i").classList.toggle("fa-chevron-up")
    }
    N.bind(t, "click", function() {
        n();
        if (t.querySelector("i").classList.contains("fa-chevron-up")) {
            setTimeout(function() {
                var r = N.bind(document, "click", function(a) {
                    N.unbind(document, "click", r, {
                        capture: false
                    });
                    if (!e.contains(a.target) && !t.contains(a.target)) {
                        n()
                    }
                }, {
                    capture: false
                })
            }, 100)
        }
    });
    N.bind(document.querySelector("#hamburger"), "click", function() {
        document.querySelector(".collapse").classList.toggle("open")
    })
};
N.install_favorites_events = function() {
    N.bind("#favcontainer", ".gallery-favorite .remove-button", "click", function() {
        var e = this;
        var t = N.find_parent(this, ".gallery-favorite");
        var n = parseInt(t.dataset.id, 10);
        var r = new N.gallery({
            id: n,
            tags: []
        });
        var a = setTimeout(function() {
            e.querySelector(".text").textContent = "Loading..."
        }, 200);
        N.http({
            url: r.get_url("favorite"),
            method: "POST",
            success: function i() {
                clearTimeout(a);
                var n = JSON.parse(this.response);
                if (!n.favorited) {
                    t.classList.add("removed");
                    e.querySelector(".text").textContent = "Undo";
                    e.querySelector(".fa").classList.remove("fa-minus");
                    e.querySelector(".fa").classList.add("fa-undo")
                } else {
                    t.classList.remove("removed");
                    e.querySelector(".text").textContent = "Remove";
                    e.querySelector(".fa").classList.add("fa-minus");
                    e.querySelector(".fa").classList.remove("fa-undo")
                }
            }
        })
    })
};
N.modal = function(e, t, n) {
    this.title = e;
    this.$wrapper = null;
    this._$content = t;
    this.buttons = n
};
N.modal.prototype.show = function() {
    var e = document.createElement("div");
    e.classList.add("modal-inner");
    var t = document.createElement("h1");
    t.textContent = this.title;
    e.appendChild(t);
    var n = document.createElement("div");
    n.classList.add("contents");
    n.appendChild(this._$content);
    e.appendChild(n);
    var r = document.createElement("div");
    r.classList.add("buttons");
    for (var a = 0; a < this.buttons.length; a++) {
        var i = this.buttons[a];
        var o = document.createElement("button");
        o.type = "button";
        o.classList.add("btn");
        o.classList.add("btn-" + i.type);
        o.textContent = i.name;
        (function(e, t) {
            N.bind(o, "click", function(n) {
                return e(n, t)
            })
        })(i.callback, this);
        r.appendChild(o)
    }
    e.appendChild(r);
    this.$wrapper = document.createElement("div");
    this.$wrapper.classList.add("modal-wrapper");
    this.$wrapper.appendChild(e);
    var s = this;
    N.bind(this.$wrapper, "click", function(e) {
        if (e.target === s.$wrapper) {
            s.close()
        }
    });
    document.body.appendChild(this.$wrapper)
};
N.modal.prototype.close = function() {
    this.$wrapper.parentNode.removeChild(this.$wrapper)
};