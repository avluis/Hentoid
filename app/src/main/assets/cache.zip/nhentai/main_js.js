(function() {
    "use strict";

    function e(e) {
        this.length = 0, this.offset = 0, this.array = new Uint8Array(e), this.view = new DataView(this.array.buffer, 0, this.length)
    }

    function t(e) {
        e--;
        for (var t = 0; 6 > t; t++) e |= e >> (1 << t);
        return e + 1
    }

    function r(e, t, r, n, i) {
        var a = !1;
        if (a) e.set(a.call(t, r, n), i);
        else
            for (var o = r; n > o; o++) e[i + o] = t[o]
    }
    var n = window.N = {};
    n.init = function() {
            var e = arguments.length <= 0 || void 0 === arguments[0] ? {} : arguments[0];
            for (var t in this) this.hasOwnProperty(t) && /^(install|patch)_/.test(t) && this[t]();
            n.options = e
        }, n.install_analytics = function() {
            window.GoogleAnalyticsObject = "ga", window.ga = window.ga || function() {
                (window.ga.q = window.ga.q || []).push(arguments)
            }, window.ga.l = +new Date, n.inject_script("https://www.google-analytics.com/analytics.js", {
                async: !0
            }), window.ga("create", "UA-52345677-1", {
                sampleRate: 5
            }), window.ga("send", "pageview")
        }, n.patch_safari_touch_hover = function() {
            n.bind(document, "touchstart", function() {}, {
                capture: !0,
                passive: !0
            })
        }, n.patch_no_console = function() {
            window.console || (window.console = {
                log: function() {},
                debug: function() {}
            })
        }, n.install_sentry = function() {
            Raven.config("https://b42380b6f72e4650ac4607e6ba15934c@sentry.nhentai.net/52175").install()
        }, n.key = {
            BACKSPACE: 8,
            TAB: 9,
            ENTER: 13,
            SHIFT: 16,
            CTRL: 17,
            ALT: 18,
            ESCAPE: 27,
            SPACEBAR: 32,
            LEFT_ARROW: 37,
            UP_ARROW: 38,
            RIGHT_ARROW: 39,
            DOWN_ARROW: 40,
            A: 65,
            D: 68,
            S: 83,
            W: 87
        }, n.cookies = {}, n.cookies.get = function(e, t) {
            for (var r = document.cookie.split(/;\s*/), n = 0; n < r.length; n++) {
                var i = r[n];
                if (0 === i.indexOf(e + "=")) return i.split("=", 2)[1]
            }
            return t
        }, n.cookies.has = function(e) {
            return n.cookies.get(e, !1) !== !1
        }, n.cookies.set = function(e, t, r) {
            var n = [e + "=" + t];
            if (r) {
                var i = new Date;
                i.setTime(i.getTime() + 1e3 * r), n.push("expires=" + i.toUTCString())
            }
            n.push("path=/"), document.cookie = n.join("; ")
        }, n.cookies["delete"] = function(e) {
            return n.cookies.set(e, "", -1)
        }, n.bind = function() {
            return "string" == typeof arguments[2] ? n.bind_dynamic.apply(null, arguments) : n.bind_regular.apply(null, arguments)
        }, n.bind_dynamic = function(e, t, r, i) {
            var a = arguments.length <= 4 || void 0 === arguments[4] ? {
                    capture: !0
                } : arguments[4],
                o = function(e) {
                    var r = n.find_parent(e.target, t, a);
                    return r ? i.apply(r, arguments) : void 0
                };
            return n.bind_regular(e, r, o, a), o
        }, n.bind_regular = function(e, t, r) {
            var i = arguments.length <= 3 || void 0 === arguments[3] ? {
                capture: !0
            } : arguments[3];
            "string" == typeof e ? e = document.querySelectorAll(e) : !(e instanceof NodeList) && e.constructor !== Array && (e = [e]);
            for (var t = t.split(/\s+/), a = 0; a < e.length; a++)
                for (var o = e[a], s = 0; s < t.length; s++) o.addEventListener(t[s], r, n.browser.supports_passive_events ? i : i.capture || !1);
            return r
        }, n.ready = function(e) {
            return n.bind_regular(document, "DOMContentLoaded", e)
        }, n.unbind = function(e, t, r) {
            var i = arguments.length <= 3 || void 0 === arguments[3] ? {
                capture: !0
            } : arguments[3];
            "string" == typeof e ? e = document.querySelectorAll(e) : !(e instanceof NodeList) && e.constructor !== Array && (e = [e]);
            for (var t = t.split(/\s+/), a = 0; a < e.length; a++)
                for (var o = e[a], s = 0; s < t.length; s++) o.removeEventListener(t[s], r, n.browser.supports_passive_events ? i : i.capture || !1)
        },
        function() {
            function e(e) {
                return function(t, r) {
                    var i = arguments.length <= 2 || void 0 === arguments[2] ? !1 : arguments[2];
                    if (i && n.matches(t, r)) return t;
                    do t = t[e]; while (t && !n.matches(t, r));
                    return t
                }
            }
            n.find_parent = e("parentNode"), n.find_next = e("nextElementSibling"), n.find_previous = e("previousElementSibling")
        }(), n.matches = function(e, t) {
            var r = e.matches || e.matchesSelector || e.webkitMatchesSelector || e.mozMatchesSelector || e.msMatchesSelector;
            if (r) return r.call(e, t);
            for (var n = document.querySelectorAll(t), i = 0; i < n.length; i++)
                if (n[i] === e) return !0;
            return !1
        }, n.format = function(e) {
            for (var t = typeof arguments[1], r = "string" === t || "number" === t ? [].slice.call(arguments, 1) : arguments[1], n = 0; n < r.length; n++) e = e.replace(RegExp("\\{" + n + "\\}", "gi"), r[n]);
            return e
        }, n.pad = function(e, t, r) {
            for (var n = e, i = 0; i < t - n.length; i++) n = r + n;
            return n
        }, n.html_escape = function(e) {
            var t = {
                "&": "&amp;",
                "<": "&lt;",
                ">": "&gt;",
                '"': "&38;",
                "'": "&#39;"
            };
            return e.toString().replace(/[&<>"']/g, function(e) {
                return t[e]
            })
        }, n.render_template = function(e) {
            var t = arguments.length <= 1 || void 0 === arguments[1] ? {} : arguments[1],
                r = "\n		var parts = [];\n\n		with (context) {\n			parts.push('" + e.replace(/[\r\t\n]/g, " ").split("<%").join("	").replace(/((^|%>)[^\t]*)'/g, "$1\r").replace(/\t!=(.*?)%>/g, "',$1,'").replace(/\t=(.*?)%>/g, "',N.html_escape($1),'").split("	").join("');").split("%>").join("parts.push('").split("\r").join("\\'") + "');\n		}\n\n		return parts.join('');";
            return t.N = n, new Function("context", r)(t)
        }, n.create_element = function(e) {
            var t = arguments.length <= 1 || void 0 === arguments[1] ? {} : arguments[1],
                r = document.createElement("div");
            return r.innerHTML = n.render_template(e, t), r.children[0]
        }, n.pretty_integer = function(e) {
            return e.toString().replace(/\B(?=(?:\d{3})+(?!\d))/g, ",")
        }, n.strip = function(e) {
            return e.replace(/^\s+|\s+$/g, "")
        }, n.forEach = function(e, t) {
            for (var r = 0; r < e.length; r++) t(e[r])
        }, n.clamp = function(e, t, r) {
            return Math.max(t, Math.min(e, r))
        }, n.extend = function(e, t) {
            var r = arguments.length <= 2 || void 0 === arguments[2] ? !1 : arguments[2];
            for (var n in t)
                if (t.hasOwnProperty(n)) {
                    if (r && e.hasOwnProperty(n)) continue;
                    e[n] = t[n]
                }
        }, n.keys = function(e) {
            if (Object.keys) return Object.keys(e);
            var t = [];
            for (var r in e) e.hasOwnProperty(r) && t.push(r);
            return t
        }, n.inject_script = function(e, t, r) {
            var i = document.createElement("script");
            n.extend(i, t), 0 === e.indexOf("//") && (e = document.location.protocol + e), i.src = e;
            var a = document.getElementsByTagName("script")[0];
            a.parentNode.insertBefore(i, a), r && n.bind(i, "load", r)
        }, n.rate_limit = function(e, t) {
            var r = null;
            return function() {
                var n = r;
                return r = Date.now(), Date.now() - n < t ? void 0 : e.apply(this, arguments)
            }
        }, n.sgn = function(e) {
            return e >= 0 ? 1 : -1
        }, n.debouncer = function(e) {
            this.delay = e, this.last_hit = null
        }, n.debouncer.prototype.hit = function() {
            this.is_ready() && (this.last_hit = +new Date)
        }, n.debouncer.prototype.is_ready = function() {
            return this.last_hit ? +new Date - this.last_hit > this.delay : !0
        }, n.show_message = function(e, t) {
            var r = document.createElement("div");
            r.classList.add("alert"), r.classList.add("alert-" + t), r.textContent = e, document.querySelector("#messages").appendChild(r)
        }, n.encode_params = function(e) {
            for (var t = [], r = n.keys(e), i = 0; i < r.length; i++) {
                var a = r[i];
                t.push(n.format("{0}={1}", encodeURIComponent(a), encodeURIComponent(e[a])))
            }
            return t.join("&")
        }, n.http = function(e) {
            var t = {
                headers: {
                    "X-CSRFToken": n.options.csrf_token,
                    "X-Requested-With": "XMLHttpRequest"
                },
                method: "GET",
                success: function() {},
                failure: function() {},
                xhr_properties: {},
                params: null,
                json: null
            };
            n.extend(e, t, !0);
            var r = new XMLHttpRequest;
            r.open(e.method, e.url, !0);
            for (var i = n.keys(e.headers), a = 0; a < i.length; a++) {
                var o = i[a];
                r.setRequestHeader(o, e.headers[o])
            }
            n.bind(r, "load", e.success), n.bind(r, "error", e.failure);
            var s = null;
            return null !== e.params ? (s = n.encode_params(e.params), r.setRequestHeader("Content-Type", "application/x-www-form-urlencoded")) : null !== e.json && (s = JSON.stringify(e.json), r.setRequestHeader("Content-Type", "application/json")), n.extend(r, e.xhr_properties), r.send(s), r
        }, n.browser = {}, n.browser.supports_passive_events = function() {
            var e = !1;
            try {
                var t = Object.defineProperty({}, "passive", {
                    get: function() {
                        e = !0
                    }
                });
                window.addEventListener("test", null, t)
            } catch (r) {}
            return e
        }, n.local_storage = {}, n.local_storage.set = function(e, t) {
            localStorage.setItem(e, JSON.stringify(t))
        }, n.local_storage.has = function(e) {
            return null !== localStorage.getItem(e)
        }, n.local_storage.get = function(e, t) {
            return n.local_storage.has(e) ? JSON.parse(localStorage.getItem(e)) : t
        }, n.local_storage["delete"] = function(e) {
            localStorage.removeItem(e)
        }, n.cookie_storage = {}, n.cookie_storage.set = function(e, t) {
            n.cookies.set(e, JSON.stringify(t), 28800)
        }, n.cookie_storage.has = function(e) {
            return n.cookies.has(e)
        }, n.cookie_storage.get = function(e, t) {
            return n.cookie_storage.has(e) ? JSON.parse(n.cookies.get(e)) : t
        }, n.cookie_storage["delete"] = function(e) {
            n.cookies["delete"](e)
        }, n.memory_storage = {}, n.memory_storage.data = {}, n.memory_storage.set = function(e, t) {
            n.memory_storage.data[e] = t
        }, n.memory_storage.has = function(e) {
            return e in n.memory_storage.data
        }, n.memory_storage.get = function(e, t) {
            return n.memory_storage.has(e) ? n.memory_storage.data[e] : t
        }, n.memory_storage["delete"] = function(e) {
            delete n.memory_storage.data[e]
        }, n.storage = function() {
            try {
                if (localStorage.setItem("_storage_test", "test"), "test" !== localStorage.getItem("_storage_test")) throw new Error("Storage does not actually work");
                return localStorage.removeItem("_storage_test"), n.local_storage
            } catch (e) {}
            try {
                if (document.cookie = "_cookie_test=test", -1 === document.cookie.indexOf("_cookie_test=test")) throw new Error("Cookies do not actually work");
                return document.cookie = "_cookie_test=test;expires=Thu, 01 Jan 1970 00:00:01 GMT", n.cookie_storage
            } catch (e) {}
            return Raven.captureException(new Error("Browser defaulting to in memory storage!")), n.memory_storage
        }(), n.install_theme_previewer = function() {
            n.ready(function() {
                var e = document.querySelector("html"),
                    t = document.querySelector("#id_theme");
                t && n.bind(t, "change", function() {
                    for (var t = e.classList, r = 0; r < t.length; r++) - 1 !== t[r].indexOf("theme-") && t.remove(t[r]);
                    t.add("theme-" + this.value.toLowerCase())
                })
            })
        }, n.lazy_loader = function(e) {
            this.$elements = [].slice.call(e), this.$elements.reverse(), this.interval = setInterval(this.show_images.bind(this), 100);
            for (var t = 0; t < this.$elements.length; t++) {
                var r = this.$elements[t];
                r.src = this.placeholder(+r.getAttribute("width"), +r.getAttribute("height"))
            }
            this.show_images()
        }, n.lazy_loader.prototype.placeholder = function() {
            var e = {};
            if (window.CanvasRenderingContext2D) {
                var t = document.createElement("canvas");
                return function(r, n) {
                    var i = r + "|" + n;
                    return i in e ? e[i] : (t.width !== r && (t.width = r), t.height !== n && (t.height = n), e[i] = t.toDataURL())
                }
            }
            return function(e, t) {
                return "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAAETCAQAAADZ34FNAAAAgUlEQVR4Ae3BMQEAAADCIPunXgsvYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADAU67SAAGCHA2qAAAAAElFTkSuQmCC"
            }
        }(), n.lazy_loader.prototype.in_viewport = function(e, t) {
            var r = e.getBoundingClientRect();
            return r.bottom >= -t && r.top <= window.innerHeight + t
        }, n.lazy_loader.prototype.show_images = function() {
            if (!this.$elements.length) return void clearInterval(this.interval);
            for (var e = !1, t = window.innerHeight / 2, r = this.$elements.length - 1; r >= 0; r--) {
                var n = this.$elements[r];
                if (!this.in_viewport(n, t)) {
                    if (!e) continue;
                    break
                }
                e = !0, this.$elements.splice(r, 1), n.src = n.getAttribute("data-src")
            }
        }, n.install_frame_buster = function() {
            -1 === ["localhost", "nhentai.net", "127.0.0.1"].indexOf(window.location.hostname) && (document.body.style = "display: none", window.location = "https://nhentai.net" + window.location.pathname + window.location.search + window.location.hash)
        }, n.reader = function(e) {
            n.extend(this, e), this.num_pages = this.gallery.images.pages.length, this.gallery_url = n.format("/g/{0}/", this.gallery.id), this.direction = 1, this.click_debouncer = new n.debouncer(500), this.$image = document.querySelector("#page-container img"), this.$image_container = document.querySelector("#image-container"), this.$image.className = "fit-horizontal", this.install_scroller(), this.install_link_catcher(), this.install_image_navigation();
            var t = this;
            n.bind(this.$image, "load", function(e) {
                return "naturalHeight" in this && this.naturalHeight + this.naturalWidth === 0 ? void Raven.captureException(new Error(JSON.stringify(e))) : this.width && this.width && this.width + this.height !== 0 ? void(1 === t.direction ? t.preload(t.current_page - 1, t.current_page + 3) : t.preload(t.current_page - 3, t.current_page + 1)) : void Raven.captureException(new Error(JSON.stringify(e)))
            }), n.bind(this.$image, "error", function(e) {
                Raven.captureException(new Error(e))
            }), n.bind(window, "popstate", function(e) {
                e.state && e.state.page && t.set_page(e.state.page, !1)
            })
        }, n.reader.prototype.get_page_url = function(e) {
            return n.format("/g/{0}/{1}/", this.gallery.id, e)
        }, n.reader.prototype.get_extension = function(e) {
            return {
                j: "jpg",
                p: "png",
                g: "gif"
            }[this.gallery.images.pages[e - 1].t]
        }, n.reader.prototype.get_image_url = function(e) {
            return n.format("{0}galleries/{1}/{2}.{3}", this.media_url, this.gallery.media_id, e, this.get_extension(e))
        }, n.reader.prototype.get_thumbnail_url = function(e) {
            return n.format("{0}galleries/{1}/{2}.{3}", this.media_url, this.gallery.media_id, e + "t", this.get_extension(e))
        }, n.reader.prototype.preload_page = function(e) {
            (new Image).src = this.get_image_url(e)
        }, n.reader.prototype.preload = n.rate_limit(function(e, t) {
            console.debug("Preloading pages", e, "to", t);
            for (var r = Math.max(1, e); r < Math.min(t, this.num_pages); r++) this.preload_page(r)
        }, 100), n.reader.prototype.stop_load = function() {
            return window.stop ? function() {
                window.stop()
            } : document.execCommand ? function() {
                document.execCommand("Stop", !1)
            } : function() {}
        }(), n.reader.prototype.set_page = function(e, t) {
            if (e !== this.current_page) {
                this.stop_load(), console.debug("Switching to page", e), this.current_page = e, this.$image.src = "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7", this.$image.src = this.get_image_url(e), this.$image.width = this.gallery.images.pages[e - 1].w, this.$image.height = this.gallery.images.pages[e - 1].h, this.$image_container.querySelector("a").href = e < this.num_pages ? this.get_page_url(e + 1) : this.gallery_url;
                var r = this.render_pagination(e);
                n.forEach(document.querySelectorAll("#page-container .pagination"), function(e) {
                    e.innerHTML = r
                }), document.title = document.title.replace(/Page (\d+) \u00bb/, n.format("Page {0} »", e)), t && history.pushState && (history.pushState({
                    page: e
                }, document.title, this.get_page_url(e)), window.ga("send", "pageview", window.location.pathname)), this.$image_container.scrollIntoView()
            }
        }, n.reader.prototype.previous_page = function() {
            this.direction = -1, this.set_page(Math.max(1, this.current_page - 1), !0)
        }, n.reader.prototype.next_page = function() {
            this.direction = 1, this.set_page(Math.min(this.current_page + 1, this.num_pages), !0)
        }, n.reader.prototype.render_pagination = function(e) {
            return n.render_template('\n		<a href="<%= r.get_page_url(1) %>" class="first"><i class="fa fa-chevron-left"></i><i class="fa fa-chevron-left"></i></a>\n\n		<% if (page > 1) { %>\n				<a href="<%= r.get_page_url(page - 1) %>" class="previous"><i class="fa fa-chevron-left"></i></a>\n		<% } else { %>\n				<a class="previous invisible"><i class="fa fa-chevron-left"></i></a>\n		<% } %>\n\n		<span class="page-number"><span class="current"><%= page %></span> <span class="divider">of</span> <span class="num-pages"><%= r.num_pages %></span></span>\n\n		<% if (page < r.num_pages) { %>\n				<a href="<%= r.get_page_url(page + 1) %>" class="next"><i class="fa fa-chevron-right"></i></a>\n		<% } else { %>\n				<a class="next invisible"><i class="fa fa-chevron-right"></i></a>\n		<% } %>\n\n		<a href="<%= r.get_page_url(r.num_pages) %>" class="last"><i class="fa fa-chevron-right"></i><i class="fa fa-chevron-right"></i></a>\n	', {
                r: this,
                page: e
            })
        }, n.reader.prototype.install_scroller = function() {
            var e = this,
                t = null;
            n.bind(document, "keydown", function(r) {
                if (!("input" === r.target.tagName.toLowerCase() || r.metaKey || r.ctrlKey || r.shiftKey || r.altKey)) {
                    t && (clearInterval(t), t = null);
                    var i = !0;
                    switch (r.which) {
                        case n.key.S:
                        case n.key.DOWN_ARROW:
                            t = setInterval(function() {
                                window.scrollBy(0, 5)
                            }, 5);
                            break;
                        case n.key.W:
                        case n.key.UP_ARROW:
                            t = setInterval(function() {
                                window.scrollBy(0, -5)
                            }, 5);
                            break;
                        case n.key.A:
                        case n.key.LEFT_ARROW:
                            e.previous_page();
                            break;
                        case n.key.D:
                        case n.key.RIGHT_ARROW:
                            e.next_page();
                            break;
                        default:
                            i = !1
                    }
                    i && r.preventDefault()
                }
            }), n.bind(document, "keyup visibilitychange", function() {
                t && (clearInterval(t), t = null)
            })
        }, n.reader.prototype.install_link_catcher = function() {
            var e = this;
            n.bind("#page-container", ".pagination a", "click", function(t) {
                var r = this.href.match(new RegExp("/g/\\d+/(\\d+)"));
                r && (t.preventDefault(), e.set_page(parseInt(r[1], 10), !0))
            }, !0)
        }, n.reader.prototype.install_image_navigation = function() {
            var e = this;
            n.bind("#image-container", "img", "click", function(t) {
                if (t.preventDefault(), e.click_debouncer.is_ready()) {
                    e.click_debouncer.hit();
                    var r = t.offsetX / this.width;.4 > r ? (console.log("You tapped left"), e.previous_page()) : (console.log("You tapped right"), e.current_page === e.num_pages ? window.location = e.gallery_url : e.next_page())
                }
            })
        }, n.relative_time = function(e) {
            var t = new Date,
                e = new Date(e),
                r = (t - e) / 1e3,
                i = [];
            i.push([r, "second"]), i.push([r / 60, "minute"]), i.push([r / 3600 % 3600, "hour"]), i.push([r / 86400 % 86400, "day"]), i.push([r / 604800 % 604800, "week"]), i.push([12 * (t.getFullYear() - e.getFullYear()) + (t.getMonth() - e.getMonth()), "month"]);
            var a = t.getFullYear() - e.getFullYear();
            (t.getMonth() < e.getMonth() || t.getMonth() == e.getMonth() && t.getDate() < e.getDate()) && a--, i.push([a, "year"]);
            for (var o = 0; o < i.length; o++) i[o][0] = Math.floor(i[o][0]) || Number.POSITIVE_INFINITY;
            i.sort(function(e, t) {
                return e[0] - t[0]
            });
            var s = i[0];
            return n.format("{0} {1}{2} ago", s[0], s[1], 1 === s[0] ? "" : "s")
        }, n.update_times = function() {
            for (var e = 6e4, t = document.querySelectorAll("time[datetime]"), r = 0; r < t.length; r++) {
                var i = t[r],
                    a = n.relative_time(i.getAttribute("datetime"));
                i.innerHTML !== a && (i.innerHTML = a), -1 !== a.indexOf("second") && (e = 1e3)
            }
            return e
        }, n.install_relative_time = function() {
            n.ready(function() {
                var e = function t() {
                    var e = n.update_times();
                    setTimeout(t, e)
                };
                e()
            })
        }, n.blacklist_tags = function(e) {
            this.tag_ids = e
        }, n.blacklist_tags.prototype.apply_css = function() {
            if (this.tag_ids && this.tag_ids.length)
                for (var e = this.tag_ids.map(function(e) {
                        return n.format('.gallery[data-tags~="{0}"]', e)
                    }).join(",") + "," + this.tag_ids.map(function(e) {
                        return n.format(".tag-{0}", e)
                    }).join(","), t = document.querySelectorAll(e), r = 0; r < t.length; r++) t[r].classList.add("blacklisted")
        }, n.CRC = {}, n.CRC.table = null, n.CRC.compute_table = function() {
            for (var e = [], t = 0; 256 > t; t++) {
                for (var r = t, n = 0; 8 > n; n++) r = 1 & r ? 3988292384 ^ r >>> 1 : r >>> 1;
                e[t] = r
            }
            return e
        }, n.CRC.crc32 = function(e) {
            var t, r = -1,
                i = n.CRC.table || (n.CRC.table = n.CRC.compute_table());
            t = e instanceof ArrayBuffer ? e.byteLength : e.length;
            for (var a = 0; t > a; a++) r = r >>> 8 ^ i[255 & (r ^ e[a])];
            return ~r
        }, e.prototype.resize_to_fit = function(e) {
            if (!(e <= this.length)) {
                if (e > this.array.length) {
                    console.log("Resizing", this.array.length, "->", e);
                    var r = new Uint8Array(t(e));
                    r.set(this.array, 0), this.array = r
                }
                this.view = new DataView(this.array.buffer, 0, e), this.length = e
            }
        }, e.prototype.extend = function(e) {
            this.resize_to_fit(this.offset + e.length), r(this.array, e.array, 0, e.length, this.offset), this.offset += e.length
        }, e.prototype.write_array = function(e) {
            this.resize_to_fit(this.offset + e.length), this.array.set(e, this.offset), this.offset += e.length
        }, e.prototype.write_short = function(e) {
            this.resize_to_fit(this.offset + 2), this.view.setUint16(this.offset, e, !0), this.offset += 2
        }, e.prototype.write_int = function(e) {
            this.resize_to_fit(this.offset + 4), this.view.setUint32(this.offset, e, !0), this.offset += 4
        }, e.prototype.write_bytes = function(e) {
            this.resize_to_fit(this.offset + e.length);
            for (var t = 0; t < e.length; t++) this.view.setUint8(this.offset++, e.charCodeAt(t), !0)
        }, e.prototype.to_blob = function(e) {
            try {
                return new Blob([this.view], {
                    type: e
                })
            } catch (t) {
                var n = new(window.BlobBuilder || window.WebKitBlobBuilder || window.MozBlobBuilder || window.MSBlobBuilder),
                    i = new ArrayBuffer(this.length),
                    a = new Uint8Array(i);
                return r(a, this.array, 0, this.length, 0), n.append(i), n.getBlob(e)
            }
        }, n.zipfile = function(t, r) {
            if (this.has_download_attribute = "download" in document.createElementNS("http://www.w3.org/1999/xhtml", "a"), !(window.Uint8Array && window.URL && URL.createObjectURL && window.Blob)) throw new Error("Browser cannot create blobs");
            if (!(this.has_download_attribute || window.saveAs || navigator.msSaveOrOpenBlob)) throw new Error("Browser cannot save blobs");
            this.file_data = new e(12e6), this.central_directory = new e(5200), this.cdr_count = 0, this.filename = t, this.total_requests = 0, this.request_count = 0;
            for (var n = 0; n < r.length; n++) this.add_url(r[n][0], r[n][1]);
            this.done = function() {}, this.progress = function(e, t) {}, this.send_progress()
        }, n.zipfile.prototype.CENTRAL_DIRECTORY_HEADER = "PK", n.zipfile.prototype.LOCAL_FILE_HEADER = "PK", n.zipfile.prototype.CENTRAL_DIRECTORY_HEADER_END = "PK", n.zipfile.prototype.shared_header = function(t, r) {
            var i = new e(26);
            return i.write_short(20), i.write_short(0), i.write_short(0), i.write_short(0), i.write_short(33), i.write_int(n.CRC.crc32(r)), i.write_int(r.length), i.write_int(r.length), i.write_short(t.length), i.write_short(0), i
        }, n.zipfile.prototype.add_file = function(e, t) {
            var r = this.shared_header(e, t),
                n = this.file_data.length;
            this.file_data.write_bytes(this.LOCAL_FILE_HEADER), this.file_data.extend(r), this.file_data.write_bytes(e + ""), this.file_data.write_array(t), this.cdr_count++, this.central_directory.write_bytes(this.CENTRAL_DIRECTORY_HEADER), this.central_directory.write_short(20), this.central_directory.extend(r), this.central_directory.write_short(0), this.central_directory.write_short(0), this.central_directory.write_short(0), this.central_directory.write_int(0), this.central_directory.write_int(n), this.central_directory.write_bytes(e), r = null
        }, n.zipfile.prototype.cdr_end = function() {
            var t = new e(50);
            return t.write_bytes(this.CENTRAL_DIRECTORY_HEADER_END), t.write_short(0), t.write_short(0), t.write_short(this.cdr_count), t.write_short(this.cdr_count), t.write_int(this.central_directory.length), t.write_int(this.file_data.length), t.write_short(0), t
        }, n.zipfile.prototype.save_blob = function() {
            var t = this.cdr_end(),
                r = new e(this.file_data.length + this.central_directory.length + t.length);
            return r.extend(this.file_data), r.extend(this.central_directory), r.extend(t), r.to_blob("application/zip")
        }, n.zipfile.prototype.download = function() {
            var e = this.save_blob(),
                t = URL.createObjectURL(e);
            if (window.saveAs) saveAs(e, this.filename);
            else if (navigator.msSaveOrOpenBlob) navigator.msSaveOrOpenBlob(e, this.filename);
            else {
                if (!this.has_download_attribute) throw new Error("Your browser can't handle JS downloads");
                var r = document.createElement("a");
                r.style.display = "none", r.href = t, r.download = this.filename, document.body.appendChild(r), r.click(), setTimeout(function() {
                    document.body.removeChild(r), window.URL.revokeObjectURL(t)
                }, 3e3)
            }
        }, n.zipfile.prototype.add_url = function(e, t) {
            var r = this;
            this.request_count++, this.total_requests++, n.http({
                method: "GET",
                url: t,
                xhr_properties: {
                    responseType: "arraybuffer"
                },
                default_headers: !1,
                success: function() {
                    r.add_file(e, new Uint8Array(this.response)), r.file_downloaded()
                },
                failure: function(e) {
                    r.error(e)
                }
            })
        }, n.zipfile.prototype.file_downloaded = function() {
            this.request_count--, this.send_progress(), 0 === this.request_count && this.done()
        }, n.zipfile.prototype.send_progress = function() {
            this.progress(this.total_requests - this.request_count, this.total_requests)
        }, n.zipfile.prototype.error = function(e) {}, n.tag = function(e, t, r, n, i) {
            var a = arguments.length <= 5 || void 0 === arguments[5] ? !1 : arguments[5];
            this.id = e, this.name = t, this.type = r, this.url = n, this.count = i, this.created = a
        }, n.tag.prototype.as_object = function() {
            return {
                id: this.id,
                name: this.name,
                type: this.type
            }
        }, n.tag.prototype.as_element = function() {
            var e = document.createElement("a");
            e.href = this.url, e.classList.add("tag"), e.classList.add("tag-" + this.id);
            var t = document.createElement("span");
            t.textContent = this.name, e.appendChild(t), e.appendChild(document.createTextNode(" "));
            var r = document.createElement("span");
            return r.classList.add("count"), this.created ? (r.textContent = "(create)", e.classList.add("tag-created")) : r.textContent = "(" + n.pretty_integer(this.count) + ")", e.appendChild(r), e.tag = this, e
        }, n.gallery = function(e) {
            for (var t = 0; t < e.tags.length; t++) {
                var r = e.tags[t];
                e.tags[t] = new n.tag(r.id, r.name, r.type, r.url, r.count)
            }
            n.extend(this, e), this.editing = !1
        }, n.gallery.prototype.get_url = function(e) {
            return n.format("/g/{0}/{1}", this.id, e)
        }, n.gallery.prototype.toggle_favorite = function() {
            document.querySelector("#favorite").disabled = !0, n.http({
                method: "POST",
                url: this.get_url("favorite"),
                success: function() {
                    var e = JSON.parse(this.response),
                        t = document.querySelector("#favorite i.fa");
                    document.querySelector("#favorite .count").textContent = e.count, document.querySelector("#favorite .text").textContent = e.favorited ? "Unfavorite" : "Favorite", document.querySelector("#favorite").disabled = !1, t.classList.toggle("fa-heart"), t.classList.toggle("fa-heart-o")
                }
            })
        }, n.gallery.prototype.download_zipfile = function() {
            for (var e = [], t = this.images.pages.toString().length, r = 0; r < this.images.pages.length; r++) {
                var i = n.pad((r + 1).toString(), t, "0"),
                    a = {
                        j: "jpg",
                        p: "png",
                        g: "gif"
                    }[this.images.pages[r].t],
                    o = n.format("//i.nhentai.net/galleries/{0}/{1}.{2}", this.media_id, r + 1, a);
                e.push([n.format("{0}.{1}", i, a), o])
            }
            var s = new n.zipfile(this.title.pretty + ".zip", e);
            s.done = function() {
                s.download()
            };
            var l = document.querySelector("#download");
            s.progress = function(e, t) {
                l.textContent = n.format("Downloaded {0} of {1}: {2}%", e, t, (100 * e / t).toFixed(2))
            }
        }, n.gallery.prototype.toggle_edit = function() {
            this.editing ? (this.editing = !1, document.querySelector("#edit .text").textContent = "Edit", document.querySelector("#edit").disabled = !0, this.end_edit()) : (this.editing = !0, document.querySelector("#edit .text").textContent = "Save", this.begin_edit())
        }, n.gallery.prototype.begin_edit = function() {
            for (var e = ["parody", "character", "tag", "artist", "group", "language", "category"], t = {
                    tag: [],
                    artist: [],
                    parody: [],
                    character: [],
                    group: [],
                    language: [],
                    category: []
                }, r = {
                    tag: "Tags",
                    artist: "Artists",
                    parody: "Parodies",
                    character: "Characters",
                    group: "Groups",
                    language: "Languages",
                    category: "Categories"
                }, i = 0; i < this.tags.length; i++) {
                var a = this.tags[i];
                t[a.type].push(a)
            }
            this.editors = [], document.querySelector("#tags").innerHTML = "";
            for (var i = 0; i < e.length; i++) {
                var o = new n.tag_editor(e[i], t[e[i]], !0);
                this.editors.push(o), o.$wrapper.querySelector(".name").textContent = r[e[i]] + ":", document.querySelector("#tags").appendChild(o.$wrapper), o.begin_edit()
            }
        }, n.gallery.prototype.end_edit = function() {
            for (var e = [], t = [], r = [], i = 0; i < this.editors.length; i++) {
                var a = this.editors[i];
                a.end_edit();
                for (var o = a.state(), s = 0; s < o.added.length; s++) {
                    var l = o.added[s]; - 1 !== l.id.toString().indexOf("new-") ? t.push({
                        name: l.name,
                        type: l.type
                    }) : e.push(l.id)
                }
                for (var s = 0; s < o.removed.length; s++) {
                    var l = o.removed[s]; - 1 === l.id.toString().indexOf("new-") && r.push(l.id)
                }
            }
            n.http({
                url: this.get_url("edit"),
                method: "POST",
                json: {
                    added_tags: e,
                    removed_tags: r,
                    created_tags: t
                },
                success: function() {
                    var e = JSON.parse(this.response);
                    e.error ? n.show_message("An error has occured: " + e.error, "danger") : n.show_message("Your edit has been saved and will be approved shortly", "success")
                },
                failure: function(e) {
                    var t = JSON.parse(this.response);
                    n.show_message("An error has occured: " + t.error, "danger")
                }
            })
        }, n.tag_autocomplete = function(e, t, r) {
            var i = arguments.length <= 3 || void 0 === arguments[3] ? {} : arguments[3];
            this.tag = e, this.type = t, this.editor = r, this.exclude = i, this.$wrapper = n.create_element('\n		<div class="tag-autocomplete">\n			<div class="autocomplete-wrapper">\n				<input type="text" class="tag tag-input" placeholder="enter a tag name" autocapitalize="none" />\n				<ul class="dropdown"></ul>\n			</div>\n\n			<div class="tag-wrapper"></div>\n		</div>\n	'), this.$autocomplete_wrapper = this.$wrapper.querySelector(".autocomplete-wrapper"), this.$tag_wrapper = this.$wrapper.querySelector(".tag-wrapper"), this.$input = this.$autocomplete_wrapper.querySelector("input"), this.$dropdown = this.$autocomplete_wrapper.querySelector("ul"), this.install_handlers()
        }, n.tag_autocomplete.prototype.install_handlers = function() {
            var e = this;
            n.bind(this.$input, "keydown", function(t) {
                var r = e.$dropdown.querySelector("li.active"),
                    i = e.$dropdown.querySelector("li"),
                    a = !!r;
                if (r = r || i, t.which === n.key.ESCAPE || "" === this.value && t.which === n.key.BACKSPACE) t.preventDefault(), this.focus(), e.remove();
                else if (t.which === n.key.UP_ARROW) r.classList.remove("active"), (n.find_previous(r, "li:not(.disabled)") || r).classList.add("active");
                else if (t.which === n.key.DOWN_ARROW) a ? (r.classList.remove("active"), (n.find_next(r, "li:not(.disabled)") || r).classList.add("active")) : r.classList.add("active");
                else if (t.which === n.key.ENTER) {
                    if (1 === e.$dropdown.children.length) r = e.$dropdown.children[0];
                    else if (!a) return;
                    var o = r.querySelector("a");
                    e.select_tag(o)
                }
            }), n.bind(this.$dropdown, "li, a", "click", function(t) {
                var r = n.matches(this, "a") ? this : this.querySelector("a");
                e.select_tag(r), t.preventDefault()
            }), n.bind(this.$dropdown, "li:not(.disabled)", "hover", function(t) {
                var r = e.$dropdown.querySelector("li.active");
                r !== this && (r && r.classList.remove("active"), this.classList.add("active"))
            }), n.bind(this.$tag_wrapper, ".tag", "click", function(t) {
                var r = e.$tag_wrapper.children[0],
                    n = "";
                r && (n = r.tag.name), e.$autocomplete_wrapper.classList.remove("hidden"), e.$tag_wrapper.innerHTML = "", e.$input.value = n, e.$input.focus(), t.preventDefault(), t.stopPropagation()
            }, {
                capture: !0
            }), this.old_value = "", n.bind(this.$input, "keyup", function(t) {
                this.value !== e.old_value && (e.show_autocomplete(this.value), e.old_value = this.value)
            }), setTimeout(function() {
                n.bind(document, "click", function(t) {
                    e.$autocomplete_wrapper.classList.contains("hidden") || e.$wrapper.contains(t.target) || e.$wrapper !== t.target && e.remove()
                }, {
                    capture: !1
                })
            }, 100)
        }, n.tag_autocomplete.prototype.remove = function() {
            this.editor.added_tags.splice(this.editor.added_tags.indexOf(this.tag), 1), this.$wrapper.parentNode.removeChild(this.$wrapper)
        }, n.tag_autocomplete.prototype.select_tag = function(e) {
            n.extend(this.tag, e.tag), e.classList.add("tag-added"), this.$tag_wrapper.appendChild(e), this.$autocomplete_wrapper.classList.add("hidden")
        }, n.tag_autocomplete.prototype.show_autocomplete = function(e) {
            var t = this;
            n.http({
                url: "/api/autocomplete",
                method: "POST",
                params: {
                    name: e,
                    type: this.type
                },
                success: function() {
                    t.$dropdown.innerHTML = "";
                    for (var r = JSON.parse(this.response), i = !1, a = 0; a < r.result.length; a++) {
                        var o = r.result[a];
                        if (!t.exclude[o.id]) {
                            i = !0;
                            var s = new n.tag(o.id, o.name, o.type, o.url, o.count),
                                l = document.createElement("li");
                            l.appendChild(s.as_element()), t.$dropdown.appendChild(l)
                        }
                    }
                    if (n.strip(e)) {
                        var l = document.createElement("li");
                        t.editor.create ? (t.tag.name = n.strip(e), t.tag.created = !0, l.appendChild(t.tag.as_element())) : i || (l.classList.add("disabled"), l.appendChild(document.createTextNode("no results"))), t.$dropdown.appendChild(l)
                    }
                }
            })
        }, n.tag_editor = function(e) {
            var t = arguments.length <= 1 || void 0 === arguments[1] ? [] : arguments[1],
                r = arguments.length <= 2 || void 0 === arguments[2] ? !1 : arguments[2];
            this.type = e, this.tags = {}, this.create = r, this.removed_tags = {}, this.added_tags = [], this.autocomplete_excluded_tags = {}, this.new_tag_counter = 0, this.$wrapper = n.create_element('\n		<div class="tag-container field-name">\n			<span class="name"></span>\n			<span class="tags"></span>\n		</div>\n	', {
                type: this.type
            });
            for (var i = 0; i < t.length; i++) this.tags[t[i].id] = t[i], this.$wrapper.appendChild(t[i].as_element());
            this.editing = !1, this.recompute_excluded_tags()
        }, n.tag_editor.prototype.recompute_excluded_tags = function() {
            for (var e = n.keys(this.autocomplete_excluded_tags), t = 0; t < e.length; t++) delete this.autocomplete_excluded_tags[e[t]];
            var r = n.keys(this.tags);
            Array.prototype.push.apply(r, this.added_tags.map(function(e) {
                return e.id
            })), Array.prototype.push.apply(r, n.keys(this.removed_tags));
            for (var t = 0; t < r.length; t++) this.autocomplete_excluded_tags[r[t]] = !0
        }, n.tag_editor.prototype.begin_edit = function() {
            if (this.editing) throw new Error("Already editing");
            this.editing = !0;
            var e = this;
            this.tag_click_callback = n.bind(this.$wrapper, ".tag-container > .tag", "click", function(t) {
                this.classList.contains("tag-new") || this.classList.contains("tag-added") || (t.preventDefault(), this.classList.contains("tag-deleted") ? delete e.removed_tags[this.tag.id] : e.removed_tags[this.tag.id] = e.tags[this.tag.id], this.classList.toggle("tag-deleted"), e.recompute_excluded_tags())
            });
            var t = n.create_element('<a class="tag tag-new">+</a>');
            n.bind(t, "click", function() {
                var t = new n.tag("new-" + e.new_tag_counter++, "", e.type, "#", 0);
                e.added_tags.push(t), e.recompute_excluded_tags();
                var r = new n.tag_autocomplete(t, e.type, e, e.autocomplete_excluded_tags);
                this.parentNode.insertBefore(r.$wrapper, this), r.$input.focus(), r.show_autocomplete("")
            }), this.$wrapper.appendChild(t)
        }, n.tag_editor.prototype.end_edit = function() {
            if (!this.editing) throw new Error("Not editing");
            this.editing = !1;
            for (var e = this.$wrapper.querySelectorAll(".tag-new"), t = 0; t < e.length; t++) e[t].parentNode.removeChild(e[t])
        }, n.tag_editor.prototype.state = function() {
            for (var e = [], t = 0, r = n.keys(this.removed_tags); t < r.length; t++) e.push(this.removed_tags[r[t]]);
            return {
                added: this.added_tags,
                removed: e
            }
        }, n.install_menu_events = function() {
            function e() {
                t.classList.toggle("open"), r.querySelector("i").classList.toggle("fa-chevron-down"), r.querySelector("i").classList.toggle("fa-chevron-up")
            }
            var t = document.querySelector(".dropdown-menu"),
                r = document.querySelector("#dropdown");
            n.bind(r, "click", function() {
                e(), r.querySelector("i").classList.contains("fa-chevron-up") && setTimeout(function() {
                    var i = n.bind(document, "click", function(a) {
                        n.unbind(document, "click", i, {
                            capture: !1
                        }), !t.contains(a.target) && !r.contains(a.target) && e()
                    }, {
                        capture: !1
                    })
                }, 100)
            }), n.bind(document.querySelector("#hamburger"), "click", function() {
                document.querySelector(".collapse").classList.toggle("open")
            })
        }, n.install_favorites_events = function() {
            n.bind("#favcontainer", ".gallery-favorite .remove-button", "click", function() {
                var e = this,
                    t = n.find_parent(this, ".gallery-favorite"),
                    r = parseInt(t.dataset.id, 10),
                    i = new n.gallery({
                        id: r,
                        tags: []
                    }),
                    a = setTimeout(function() {
                        e.querySelector(".text").textContent = "Loading..."
                    }, 200);
                n.http({
                    url: i.get_url("favorite"),
                    method: "POST",
                    success: function() {
                        clearTimeout(a);
                        var r = JSON.parse(this.response);
                        r.favorited ? (t.classList.remove("removed"), e.querySelector(".text").textContent = "Remove", e.querySelector(".fa").classList.add("fa-minus"), e.querySelector(".fa").classList.remove("fa-undo")) : (t.classList.add("removed"), e.querySelector(".text").textContent = "Undo", e.querySelector(".fa").classList.remove("fa-minus"), e.querySelector(".fa").classList.add("fa-undo"))
                    }
                })
            })
        }
}).call(this);