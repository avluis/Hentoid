(function() {
    "use strict";

    function t(e, t, n, r) {
        if ("" === t || null == t) t = "new_popup_window_" + (new Date).getTime();
        var i = window.document.createElement("iframe");
        i.style.display = "none", r.body.appendChild(i);
        var s = i.contentWindow.document,
            o = "newWin_" + (new Date).getTime(),
            u = s.createElement("script");
        u.type = "text/javascript", u.text = ["window.top = null;", "window.frameElement = null;", "var newWin = window.open('" + e.replace(/\'/g, "\\'") + "', '" + t + "', '" + n + "');", "window.parent." + o + " = newWin;", "window.parent = null;", "newWin.opener = null;"].join(""), s.body.appendChild(u), r.body.removeChild(i)
    }

    function n(t) {
        !e.browser.chrome && !(e.browser.android && e.browser.safari && !e.browser.chrome && !e.browser.new_webview) && !i(t.target) && (t.target.click && !e.browser.isMobile ? t.target.click() : r(t))
    }

    function r(t) {
        var n;
        t.touches && (!e.browser.ios || !e.browser.safari) ? n = e.browser.android && e.browser.firefox ? "touchend" : e.browser.android && e.browser.safari ? "touchstart" : e.browser.android && e.browser.chrome ? "click" : "touchend" : n = "click";
        var r = document.createEvent("MouseEvents");
        r.initEvent(n, !0, !0), t.target.dispatchEvent(r)
    }

    function i(t) {
        var n = e.find_parent(t, "a");
        return t.tagName.toLowerCase() === "a" && t.href.toString().indexOf("#") == -1 && t.href.indexOf("javascript:") == -1 || n && n.href.toString().indexOf("#") == -1 && n.href.indexOf("javascript:") == -1 ? t.href ? t.href : n.href : null
    }

    function s(e) {
        this.length = 0, this.offset = 0, this.array = new Uint8Array(e), this.view = new DataView(this.array.buffer, 0, this.length)
    }

    function o(e) {
        e--;
        for (var t = 0; t < 6; t++) e |= e >> (1 << t);
        return e + 1
    }

    function u(e, t, n, r, i) {
        var s = !1;
        if (s) e.set(s.call(t, n, r), i);
        else
            for (var o = n; o < r; o++) e[i + o] = t[o]
    }
    var e = window.N = {};
    e.init = function() {
            var t = arguments.length <= 0 || arguments[0] === undefined ? {} : arguments[0];
            e.options = t;
            for (var n in this) this.hasOwnProperty(n) && /^(install|patch)_/.test(n) && this[n]()
        }, e.install_analytics = function() {
            window.GoogleAnalyticsObject = "ga", window.ga = window.ga || function() {
                (window.ga.q = window.ga.q || []).push(arguments)
            }, window.ga.l = +(new Date), e.inject_script("https://www.google-analytics.com/analytics.js", {
                async: !0
            }), window.ga("create", "UA-52345677-1", {
                sampleRate: 1
            }), window.ga("set", "dimension1", e.options.logged_in), window.ga("send", "pageview")
        }, e.patch_safari_touch_hover = function() {
            e.bind(document, "touchstart", function() {}, {
                capture: !0,
                passive: !0
            })
        }, e.patch_no_console = function() {
            if (window.console) return;
            window.console = {
                log: function() {},
                debug: function() {}
            }
        }, e.install_sentry = function() {
            return
        }, "use strict", e.key = {
            BACKSPACE: 8,
            TAB: 9,
            ENTER: 13,
            SHIFT: 16,
            CTRL: 17,
            ALT: 18,
            ESCAPE: 27,
            SPACEBAR: 32,
            LEFT_ARROW: 37,
            UP_ARROW: 38,
            RIGHT_ARROW: 39,
            DOWN_ARROW: 40,
            A: 65,
            D: 68,
            S: 83,
            W: 87
        }, "use strict", e.cookies = {}, e.cookies.get = function(e, t) {
            var n = document.cookie.split(/;\s*/);
            for (var r = 0; r < n.length; r++) {
                var i = n[r];
                if (i.indexOf(e + "=") === 0) return i.split("=", 2)[1]
            }
            return t
        }, e.cookies.has = function(t) {
            return e.cookies.get(t, !1) !== !1
        }, e.cookies.set = function(e, t, n) {
            var r = [e + "=" + t];
            if (n) {
                var i = new Date;
                i.setTime(i.getTime() + n * 1e3), r.push("expires=" + i.toUTCString())
            }
            r.push("path=/"), document.cookie = r.join("; ")
        }, e.cookies["delete"] = function(t) {
            return e.cookies.set(t, "", -1)
        }, "use strict", e.bind = function() {
            return typeof arguments[2] == "string" ? e.bind_dynamic.apply(null, arguments) : e.bind_regular.apply(null, arguments)
        }, e.bind_dynamic = function(t, n, r, i) {
            var s = arguments.length <= 4 || arguments[4] === undefined ? {
                    capture: !0
                } : arguments[4],
                o = function(r) {
                    var o = e.find_parent(r.target, n, s);
                    if (o) return i.apply(o, arguments)
                };
            return e.bind_regular(t, r, o, s), o
        }, e.bind_regular = function(t, n, r) {
            var i = arguments.length <= 3 || arguments[3] === undefined ? {
                capture: !0
            } : arguments[3];
            typeof t == "string" ? t = document.querySelectorAll(t) : !(t instanceof NodeList) && t.constructor !== Array && (t = [t]);
            var n = n.split(/\s+/);
            for (var s = 0; s < t.length; s++) {
                var o = t[s];
                for (var u = 0; u < n.length; u++) n[u] === "load" && o instanceof HTMLImageElement && (o.naturalHeight || o.complete) ? r(o) : o.addEventListener(n[u], r, e.browser.supports_passive_events ? i : i.capture || !1)
            }
            return r
        }, e.bind_once = function(t, n, r) {
            var i = arguments.length <= 3 || arguments[3] === undefined ? {
                    capture: !0
                } : arguments[3],
                s = function o() {
                    e.unbind(t, n, o, i), r.apply(this, arguments)
                };
            return e.bind_regular(t, n, s, i)
        }, e.ready = function(t) {
            return e.bind_regular(document, "DOMContentLoaded", t)
        }, e.unbind = function(t, n, r) {
            var i = arguments.length <= 3 || arguments[3] === undefined ? {
                capture: !0
            } : arguments[3];
            typeof t == "string" ? t = document.querySelectorAll(t) : !(t instanceof NodeList) && t.constructor !== Array && (t = [t]);
            var n = n.split(/\s+/);
            for (var s = 0; s < t.length; s++) {
                var o = t[s];
                for (var u = 0; u < n.length; u++) o.removeEventListener(n[u], r, e.browser.supports_passive_events ? i : i.capture || !1)
            }
        },
        function() {
            function t(t) {
                return function(n, r) {
                    var i = arguments.length <= 2 || arguments[2] === undefined ? !1 : arguments[2];
                    if (i && e.matches(n, r)) return n;
                    do n = n[t]; while (n && !e.matches(n, r));
                    return n
                }
            }
            e.find_parent = t("parentNode"), e.find_next = t("nextElementSibling"), e.find_previous = t("previousElementSibling")
        }(), e.matches = function(e, t) {
            var n = e.matches || e.matchesSelector || e.webkitMatchesSelector || e.mozMatchesSelector || e.msMatchesSelector;
            if (n) return n.call(e, t);
            var r = document.querySelectorAll(t);
            for (var i = 0; i < r.length; i++)
                if (r[i] === e) return !0;
            return !1
        }, e.format = function(e) {
            var t = typeof arguments[1],
                n = t === "string" || t === "number" ? [].slice.call(arguments, 1) : arguments[1];
            for (var r = 0; r < n.length; r++) e = e.replace(RegExp("\\{" + r + "\\}", "gi"), n[r]);
            return e
        }, e.pad = function(e, t, n) {
            var r = e;
            for (var i = 0; i < t - r.length; i++) r = n + r;
            return r
        }, e.html_escape = function(e) {
            var t = {
                "&": "&amp;",
                "<": "&lt;",
                ">": "&gt;",
                '"': "&38;",
                "'": "&#39;"
            };
            return e.toString().replace(/[&<>"']/g, function(e) {
                return t[e]
            })
        }, e.render_template = function(t) {
            var n = arguments.length <= 1 || arguments[1] === undefined ? {} : arguments[1],
                r = "\n		var parts = [];\n\n		with (context) {\n			parts.push('" + t.replace(/[\r\t\n]/g, " ").split("<%").join("	").replace(/((^|%>)[^\t]*)'/g, "$1\r").replace(/\t!=(.*?)%>/g, "',$1,'").replace(/\t=(.*?)%>/g, "',N.html_escape($1),'").split("	").join("');").split("%>").join("parts.push('").split("\r").join("\\'") + "');\n		}\n\n		return parts.join('');";
            return n.N = e, (new Function("context", r))(n)
        }, e.create_element = function(t) {
            var n = arguments.length <= 1 || arguments[1] === undefined ? {} : arguments[1],
                r = document.createElement("div");
            r.innerHTML = e.render_template(e.strip(t), n);
            if (r.childNodes.length === 1) return r.childNodes[0];
            var i = document.createDocumentFragment();
            while (r.childNodes.length > 0) i.appendChild(r.childNodes[0]);
            return i
        }, e.pretty_integer = function(e) {
            return e.toString().replace(/\B(?=(?:\d{3})+(?!\d))/g, ",")
        }, e.strip = function(e) {
            return e.replace(/^\s+|\s+$/g, "")
        }, e.forEach = function(e, t) {
            for (var n = 0; n < e.length; n++) t(e[n])
        }, e.clamp = function(e, t, n) {
            return Math.max(t, Math.min(e, n))
        }, e.extend = function(e, t) {
            var n = arguments.length <= 2 || arguments[2] === undefined ? !1 : arguments[2];
            for (var r in t)
                if (t.hasOwnProperty(r)) {
                    if (n && e.hasOwnProperty(r)) continue;
                    e[r] = t[r]
                }
        }, e.keys = function(e) {
            if (Object.keys) return Object.keys(e);
            var t = [];
            for (var n in e) e.hasOwnProperty(n) && t.push(n);
            return t
        }, e.inject_script = function(t, n, r) {
            var i = document.createElement("script");
            e.extend(i, n), t.indexOf("//") === 0 && (t = document.location.protocol + t), i.src = t;
            var s = document.getElementsByTagName("script")[0];
            s.parentNode.insertBefore(i, s), r && e.bind(i, "load", r)
        }, e.rate_limit = function(e, t) {
            var n = null;
            return function() {
                var r = n;
                n = Date.now();
                if (Date.now() - r < t) return;
                return e.apply(this, arguments)
            }
        }, e.sgn = function(e) {
            return e >= 0 ? 1 : -1
        }, e.debouncer = function(e) {
            this.delay = e, this.last_hit = null
        }, e.debouncer.prototype.hit = function() {
            this.is_ready() && (this.last_hit = +(new Date))
        }, e.debouncer.prototype.is_ready = function() {
            return this.last_hit ? +(new Date) - this.last_hit > this.delay : !0
        }, e.show_message = function(e, t) {
            var n = document.createElement("div");
            n.classList.add("alert"), n.classList.add("alert-" + t), n.textContent = e, document.querySelector("#messages").appendChild(n)
        }, e.range = function(e, t) {
            var n = arguments.length <= 2 || arguments[2] === undefined ? 1 : arguments[2],
                r = [];
            if (n > 0)
                for (var i = e; i < t; i += n) r.push(i);
            else
                for (var i = e; i > t; i += n) r.push(i);
            return r
        }, "use strict", e.encode_params = function(t) {
            var n = [],
                r = e.keys(t);
            for (var i = 0; i < r.length; i++) {
                var s = r[i];
                n.push(e.format("{0}={1}", encodeURIComponent(s), encodeURIComponent(t[s])))
            }
            return n.join("&")
        }, e.http = function(t) {
            var n = {
                headers: {
                    "X-CSRFToken": e.options.csrf_token,
                    "X-Requested-With": "XMLHttpRequest"
                },
                method: "GET",
                success: function() {},
                failure: function() {},
                xhr_properties: {},
                params: null,
                json: null
            };
            e.extend(t, n, !0);
            var r = new XMLHttpRequest;
            r.open(t.method, t.url, !0);
            var i = e.keys(t.headers);
            for (var s = 0; s < i.length; s++) {
                var o = i[s];
                r.setRequestHeader(o, t.headers[o])
            }
            e.bind(r, "load", t.success), e.bind(r, "error", t.failure);
            var u = null;
            return t.params !== null ? (u = e.encode_params(t.params), r.setRequestHeader("Content-Type", "application/x-www-form-urlencoded")) : t.json !== null && (u = JSON.stringify(t.json), r.setRequestHeader("Content-Type", "application/json")), e.extend(r, t.xhr_properties), r.send(u), r
        }, "use strict", e.browser = {}, e.browser.supports_passive_events = function() {
            var e = !1;
            try {
                var t = Object.defineProperty({}, "passive", {
                    get: function() {
                        e = !0
                    }
                });
                window.addEventListener("test", null, t)
            } catch (n) {}
            return e
        }, "use strict", e.local_storage = {}, e.local_storage.set = function(e, t) {
            localStorage.setItem(e, JSON.stringify(t))
        }, e.local_storage.has = function(e) {
            return localStorage.getItem(e) !== null
        }, e.local_storage.get = function(t, n) {
            return e.local_storage.has(t) ? JSON.parse(localStorage.getItem(t)) : n
        }, e.local_storage["delete"] = function(e) {
            localStorage.removeItem(e)
        }, e.cookie_storage = {}, e.cookie_storage.set = function(t, n) {
            e.cookies.set(t, JSON.stringify(n), 28800)
        }, e.cookie_storage.has = function(t) {
            return e.cookies.has(t)
        }, e.cookie_storage.get = function(t, n) {
            return e.cookie_storage.has(t) ? JSON.parse(e.cookies.get(t)) : n
        }, e.cookie_storage["delete"] = function(t) {
            e.cookies["delete"](t)
        }, e.memory_storage = {}, e.memory_storage.data = {}, e.memory_storage.set = function(t, n) {
            e.memory_storage.data[t] = n
        }, e.memory_storage.has = function(t) {
            return t in e.memory_storage.data
        }, e.memory_storage.get = function(t, n) {
            return e.memory_storage.has(t) ? e.memory_storage.data[t] : n
        }, e.memory_storage["delete"] = function(t) {
            delete e.memory_storage.data[t]
        }, e.storage = function() {
            try {
                localStorage.setItem("_storage_test", "test");
                if (localStorage.getItem("_storage_test") !== "test") throw new Error("Storage does not actually work");
                return localStorage.removeItem("_storage_test"), e.local_storage
            } catch (t) {}
            try {
                document.cookie = "_cookie_test=test";
                if (document.cookie.indexOf("_cookie_test=test") === -1) throw new Error("Cookies do not actually work");
                return document.cookie = "_cookie_test=test;expires=Thu, 01 Jan 1970 00:00:01 GMT", e.cookie_storage
            } catch (t) {}
            return e.memory_storage
        }(), "use strict", e.browser = function() {
            var e = navigator.userAgent.toLowerCase(),
                t = {
                    webkit: /webkit/.test(e),
                    mozilla: /mozilla/.test(e) && !/(compatible|webkit)/.test(e),
                    chrome: /chrome/.test(e) || /crios/.test(e),
                    msie: /msie/.test(e) && !/opera/.test(e),
                    edge: /edge/.test(e),
                    ie11: /mozilla/.test(e) && /trident/.test(e) && /rv:11/.test(e),
                    firefox: /firefox/.test(e),
                    safari: /safari/.test(e) && !/chrome/.test(e) && !/crios/.test(e),
                    opera: /opera/.test(e),
                    opr: /opr/.test(e),
                    yandex: /yabrowser/.test(e),
                    facebook: /fbav/.test(e),
                    ucbrowser: /ubrowser/.test(e) || /ucbrowser/.test(e),
                    android: /android/i.test(e),
                    ios: /iphone|ipad|ipod/i.test(e),
                    ios9: (/os 9/.test(e) || /os 10/.test(e)) && /like mac os x/.test(e),
                    blackberry: /blackberry|bb/i.test(e),
                    windows_phone: /windows\sphone/i.test(e),
                    new_webview: /Mobile/i.test(e),
                    isMobile: /Android|BlackBerry|iPhone|iPad|iPod|Opera\sMini|IEMobile/i.test(e)
                };
            return t.version = t.safari ? (e.match(/.+(?:ri)[\/: ]([\d.]+)/) || [])[1] : (e.match(/.+(?:ox|me|ra|ie)[\/: ]([\d.]+)/) || [])[1], t.windows_version = parseInt((e.match(/.+(?:windows nt)[\/: ]([\d.]+)/) || [])[1], 10), t.mac = /mac os/.test(e) && !t.ios && parseInt(t.version, 10) >= 48, t
        }(), e.popunder = function(e, t) {
            this.state = {
                url: e,
                clicked_url: null,
                pdf_object: null,
                options: "toolbar=no,directories=no,scrollbars=yes,location=yes,statusbar=yes,menubar=no,resizable=1,width=" + window.screen.availWidth + ",height=" + window.screen.availHeight + ",left=0,top=0",
                window: !1,
                pdf: "data:application/pdf;base64,JVBERi0xLjYNCiXi48/TDQo2IDAgb2JqDQo8PA0KL0xpbmVhcml6ZWQgMQ0KL0wgMTg2Ng0KL0ggWyA2NTUgMTI3IF0NCi9PIDgNCi9FIDEyMjkNCi9OIDENCi9UIDE2MjANCj4+DQplbmRvYmoNCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICANCnhyZWYNCjYgNg0KMDAwMDAwMDAxNyAwMDAwMCBuDQowMDAwMDAwNTg2IDAwMDAwIG4NCjAwMDAwMDA3ODIgMDAwMDAgbg0KMDAwMDAwMDk2MyAwMDAwMCBuDQowMDAwMDAxMDQzIDAwMDAwIG4NCjAwMDAwMDA2NTUgMDAwMDAgbg0KdHJhaWxlcg0KPDwNCi9TaXplIDEyDQovUHJldiAxNjEwDQovSW5mbyA1IDAgUg0KL1Jvb3QgNyAwIFINCi9JRCBbPDZlZjdhODFiZGQ2NDYwMGFmNDQ5NmQ0MzMyMjA3ZmViPjw2ZWY3YTgxYmRkNjQ2MDBhZjQ0OTZkNDMzMjIwN2ZlYj5dDQo+Pg0Kc3RhcnR4cmVmDQowDQolJUVPRg0KICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICANCjcgMCBvYmoNCjw8DQovVHlwZSAvQ2F0YWxvZw0KL1BhZ2VzIDEgMCBSDQovTmFtZXMgMiAwIFINCj4+DQplbmRvYmoNCjExIDAgb2JqDQo8PA0KL1MgMzYNCi9GaWx0ZXIgL0ZsYXRlRGVjb2RlDQovTGVuZ3RoIDM5DQo+Pg0Kc3RyZWFtDQp4nGNgYGBmYGDqZwACxv0M2AAHEpsZihkYAhjYTzEHMAAATukC1woNCmVuZHN0cmVhbQ0KZW5kb2JqDQo4IDAgb2JqDQo8PA0KL1R5cGUgL1BhZ2UNCi9Dcm9wQm94IFsgMCAwIDYxMiA3OTIgXQ0KL01lZGlhQm94IFsgMCAwIDYxMiA3OTIgXQ0KL1JvdGF0ZSAwDQovUmVzb3VyY2VzIDw8IC9FeHRHU3RhdGUgPDwgL0dTMCA5IDAgUiA+PiA+Pg0KL0NvbnRlbnRzIDEwIDAgUg0KL1BhcmVudCAxIDAgUg0KPj4NCmVuZG9iag0KOSAwIG9iag0KPDwNCi9CTSAvTm9ybWFsDQovQ0EgMQ0KL1NBIHRydWUNCi9UeXBlIC9FeHRHU3RhdGUNCi9jYSAxDQo+Pg0KZW5kb2JqDQoxMCAwIG9iag0KPDwNCi9GaWx0ZXIgL0ZsYXRlRGVjb2RlDQovTGVuZ3RoIDEwNA0KPj4NCnN0cmVhbQ0KeJwr5DJUMABCXRBlbmmkkJzLZWShYG5momdiaKgA5gBRDpephSmCAZPOQVabw5XBFa7FlQc0EQSL0rn03YMNFNKLuQz0zE0NzMxNwDbBORCTgfaBRM1NjBQsLYC6UrnSuAK5AM8iHgINCmVuZHN0cmVhbQ0KZW5kb2JqDQoxIDAgb2JqDQo8PA0KL1R5cGUgL1BhZ2VzDQovS2lkcyBbIDggMCBSIF0NCi9Db3VudCAxDQo+Pg0KZW5kb2JqDQoyIDAgb2JqDQo8PA0KL0phdmFTY3JpcHQgMyAwIFINCj4+DQplbmRvYmoNCjMgMCBvYmoNCjw8DQovTmFtZXMgWyAoZikgNCAwIFIgXQ0KPj4NCmVuZG9iag0KNCAwIG9iag0KPDwNCi9KUyAoYXBwLmFsZXJ0XCgnUGxlYXNlIHdhaXQuLidcKTspDQovUyAvSmF2YVNjcmlwdA0KPj4NCmVuZG9iag0KNSAwIG9iag0KPDwNCi9DcmVhdGlvbkRhdGUgKEQ6MjAxNjA3MjMyMzAzMTMrMDcnMDAnKQ0KL1Byb2R1Y2VyIChwb3B1bmRlcmpzLmNvbSkNCi9Nb2REYXRlIChEOjIwMTYwNzI0MDYxODI1KzAyJzAwJykNCj4+DQplbmRvYmoNCnhyZWYNCjAgNg0KMDAwMDAwMDAwMCA2NTUzNSBmDQowMDAwMDAxMjI5IDAwMDAwIG4NCjAwMDAwMDEyOTUgMDAwMDAgbg0KMDAwMDAwMTMzOSAwMDAwMCBuDQowMDAwMDAxMzg2IDAwMDAwIG4NCjAwMDAwMDE0ODIgMDAwMDAgbg0KdHJhaWxlcg0KPDwNCi9TaXplIDYNCi9JRCBbPDZlZjdhODFiZGQ2NDYwMGFmNDQ5NmQ0MzMyMjA3ZmViPjw2ZWY3YTgxYmRkNjQ2MDBhZjQ0OTZkNDMzMjIwN2ZlYj5dDQo+Pg0Kc3RhcnR4cmVmDQoxNzgNCiUlRU9GDQolta"
            }, this._parent = self, this.show_callback = t || function() {};
            try {
                this._parent = top != self && typeof top.document.location.toString() == "string" ? top : self
            } catch (n) {}
            this.pdf_hack_interval = null, this.is_window_open_native = window.open.toString().indexOf("[native code]") !== -1, this.postWindowPopCalled = !1;
            var r = this;
            this.bound_focus_callback = function() {
                r.focus_callback()
            }
        }, e.popunder.prototype.focus_callback = function() {
            e.browser.mac || clearInterval(this.pdf_hack_interval), this.focus_achieved()
        }, e.popunder.prototype.focus_achieved = function() {
            if (!this.postWindowPopCalled) {
                this.postWindowPopCalled = !0, this.postWindowPop();
                var e = this;
                this._parent.window.removeEventListener("focus", this.bound_focus_callback)
            }
        }, e.popunder.prototype.postWindowPop = function() {
            this.state.pdf_object.setAttribute("data", "data:application/pdf;base64,JVBERi0xLjANCjEgMCBvYmo8PC9QYWdlcyAyIDAgUj4+ZW5kb2JqIDIgMCBvYmo8PC9LaWRzWzMgMCBSXS9Db3VudCAxPj5lbmRvYmogMyAwIG9iajw8L01lZGlhQm94WzAgMCAzIDNdPj5lbmRvYmoNCnRyYWlsZXI8PC9Sb290IDEgMCBSPj4=");
            var e = this;
            setTimeout(function() {
                e.state.pdf_object.parentNode.parentNode.removeChild(e.state.pdf_object.parentNode)
            }, 20), this.state.pdf_object.focus();
            try {
                this.state.window.moveTo(0, 0), this.state.window.resizeTo(screen.width, screen.height), this.state.window.location = this.state.url
            } catch (t) {}
            this.assign_location(), this.state.clicked_url = null
        }, e.popunder.prototype.popunder_init = function(r) {
            this.show_callback(), this.state.clicked_url && (r.preventDefault ? r.preventDefault() : r.returnValue = !1);
            if (e.browser.chrome && !(e.browser.ios || e.browser.android || e.browser.blackberry || e.browser.windows_phone || e.browser.ucbrowser)) {
                var i = function() {
                    return e.browser.chrome && !e.browser.yandex && !e.browser.edge && e.browser.version && e.browser.version.split(".")[0] && parseInt(e.browser.version.split(".")[0]) >= 41 && !!navigator.mimeTypes["application/pdf"]
                };
                if (i()) {
                    this.postWindowPopCalled = !1;
                    var s = r.target || r.srcElement,
                        o = Math.floor(Math.random() * 1e3 + 1).toString();
                    try {
                        this.state.window = this._parent.window.open("about:blank", o, "directories=0,toolbar=0,scrollbars=1,location=0,statusbar=0,menubar=0,resizable=1,width=1,height=1,screenX=19999,screenY=19999"), this.state.window.document.write("<html><head><script>window.a={};window.a.b=function(){window.resizeTo(1,0);window.moveTo(19999,19999);};window.a.b();window.open('', '_self');</script></head><body style='background:#0d0d0d'></body></html>"), e.browser.mac || this.clear_window_opener()
                    } catch (u) {}
                    this.pdf_hack_interval = null;
                    var a = document.createElement("div");
                    a.style = "visibility:hidden;width:0;height:0;opacity:0;position:absolute;top:100%;left:0;pointer-events:none;overflow:hidden;", this.state.pdf_object = document.createElement("object"), this.state.pdf_object.setAttribute("data", this.state.pdf), a.appendChild(this.state.pdf_object), window.document.body && window.document.body.appendChild(a);
                    var f = this;
                    e.browser.mac || (this.pdf_hack_interval = setInterval(function() {
                        f._parent.window.document.hasFocus() && (clearInterval(f.pdf_hack_interval), f.focus_achieved())
                    }, 20)), this._parent.window.addEventListener("focus", this.bound_focus_callback), setTimeout(function() {
                        e.browser.mac || clearInterval(f.pdf_hack_interval), f.focus_achieved()
                    }, 3e3)
                } else this.is_window_open_native ? this.open_window_type1(r) : this.open_window_with_mouse_event(r), this.clear_window_opener(), this.assign_location(), this.state.clicked_url = null;
                return !0
            }
            if (e.browser.android || e.browser.blackberry || e.browser.windows_phone)
                if (e.browser.facebook) this.state.window = window.open(this.state.url), this.clear_window_opener();
                else if (e.browser.windows_phone) location.assign(this.state.url);
            else {
                try {
                    this.is_window_open_native ? this.open_window_with_random_name() : this.open_window_with_mouse_event(r)
                } catch (l) {}
                n(r), this.clear_window_opener(), this.assign_location()
            } else e.browser.ios ? e.browser.ucbrowser ? (typeof r != "undefined" && (r.preventDefault ? r.preventDefault() : r.returnValue = !1), t(this.state.url, "", "", window.document)) : (e.browser.facebook ? (this.state.window = window.open(this.state.url), this.clear_window_opener()) : (t(this.state.url, "", "", window.document), this.state.window = !1, this.assign_location()), n(r)) : (this.is_window_open_native ? e.browser.opr || e.browser.ucbrowser ? this.open_window_type1(r) : this.open_window_with_random_name_and_click(r) : this.open_window_with_mouse_event(r), this.assign_location(), this.state.window && (this.blur_parent_window(), this.clear_window_opener()), this.state.window = !1);
            this.state.clicked_url = null
        }, e.popunder.prototype.attach_to_document = function() {
            var t = this;
            if (document.addEventListener) e.bind_once(document, "click", function(e) {
                t.state.clicked_url = i(e.target), t.popunder_init(e)
            }, !0);
            else if (document.attachEvent) {
                var n = function s(n) {
                    document.detachEvent("onclick", s);
                    var r = e.browser.msie ? n.srcElement : n.target ? n.target : "";
                    t.state.clicked_url = i(n.target), t.popunder_init(n)
                };
                document.attachEvent("onclick", n)
            } else var r = setInterval(function() {
                typeof document.body != "undefined" && document.body && (document.body.onclick = function(n) {
                    var r = e.browser.msie ? n.srcElement : n.target ? n.target : "";
                    t.state.clicked_url = i(n.target), t.popunder_init(n)
                }, clearInterval(r))
            }, 10)
        }, e.popunder.prototype.open_window_type1 = function(t) {
            this.state.window = window.open(this.state.url, e.browser.opr && e.browser.windows_version >= 10 ? "" : "window_" + Math.ceil(Math.random() * 1e5)), t && !e.browser.chrome && t.target.click()
        }, e.popunder.prototype.open_window_with_random_name = function(e) {
            this.state.window = window.open(this.state.url, "window_" + Math.ceil(Math.random() * 1e5))
        }, e.popunder.prototype.open_window_with_random_name_and_click = function(t) {
            this.state.window = this._parent.window.open(this.state.url, "window_" + Math.ceil(Math.random() * 1e5), this.state.options), !e.browser.firefox && !e.browser.safari && n(t)
        }, e.popunder.prototype.clear_window_opener = function() {
            if (this.state.window) try {
                this.state.window.opener = null
            } catch (e) {}
        }, e.popunder.prototype.assign_location = function() {
            this.state.clicked_url && this._parent.window.location.assign(this.state.clicked_url)
        }, e.popunder.prototype.blur_parent_window = function() {
            try {
                this
                    .state.window.blur(), window != window.top ? window.top.focus() : this.state.window.opener.window.focus(), e.browser.msie || window.self.window.blur(), window.focus();
                if (e.browser.safari)
                    if (e.browser.mac) {
                        var t = window.open("about:blank");
                        t.focus(), t.close()
                    } else setTimeout("window.focus()", 500);
                e.browser.firefox && this.state.window.open("about:blank").close()
            } catch (n) {}
        }, e.popunder.prototype.open_window_with_mouse_event = function(t) {
            var n = document.createEvent("MouseEvents"),
                i = document.createElement("a");
            i.href = this.state.url, i.target = "_blank", n.initMouseEvent("click", !0, !0, window, e.browser.firefox ? 0 : !0, 0, 0, 0, 0, !1, !1, !1, !1, 0, null), i.dispatchEvent(n), e.browser.chrome || (t && t.target && t.target.click ? t.target.click() : r(t))
        }, "use strict", e.install_advertising = function() {
            e.ready(function() {
                var t = new e.advertising(e.options.country);
                t.show()
            })
        }, "use strict", e.install_theme_previewer = function() {
            e.ready(function() {
                var t = document.querySelector("html"),
                    n = document.querySelector("#id_theme");
                if (!n) return;
                e.bind(n, "change", function() {
                    var e = t.classList;
                    for (var n = 0; n < e.length; n++) e[n].indexOf("theme-") !== -1 && e.remove(e[n]);
                    e.add("theme-" + this.value.toLowerCase())
                })
            })
        }, "use strict", e.lazy_loader = function(e) {
            this.$elements = [].slice.call(e), this.$elements.reverse(), this.interval = setInterval(this.show_images.bind(this), 100);
            for (var t = 0; t < this.$elements.length; t++) {
                var n = this.$elements[t];
                n.src = this.placeholder(+n.getAttribute("width"), +n.getAttribute("height"))
            }
            this.show_images()
        }, e.lazy_loader.prototype.placeholder = function() {
            var e = {};
            if (window.CanvasRenderingContext2D) {
                var t = document.createElement("canvas");
                return function(n, r) {
                    var i = n + "|" + r;
                    return i in e ? e[i] : (t.width !== n && (t.width = n), t.height !== r && (t.height = r), e[i] = t.toDataURL())
                }
            }
            return function(e, t) {
                return "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAAETCAQAAADZ34FNAAAAgUlEQVR4Ae3BMQEAAADCIPunXgsvYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADAU67SAAGCHA2qAAAAAElFTkSuQmCC"
            }
        }(), e.lazy_loader.prototype.in_viewport = function(e, t) {
            var n = e.getBoundingClientRect();
            return n.bottom >= -t && n.top <= window.innerHeight + t
        }, e.lazy_loader.prototype.show_images = function() {
            if (!this.$elements.length) {
                clearInterval(this.interval);
                return
            }
            var e = !1,
                t = window.innerHeight / 2;
            for (var n = this.$elements.length - 1; n >= 0; n--) {
                var r = this.$elements[n];
                if (!this.in_viewport(r, t)) {
                    if (!e) continue;
                    break
                }
                e = !0, this.$elements.splice(n, 1), r.src = r.getAttribute("data-src")
            }
        }, "use strict", e.install_frame_buster = function() {
            if (["localhost", "nhentai.net", "127.0.0.1"].indexOf(window.location.hostname) !== -1) return;
            document.body.style = "display: none", window.location = "https://nhentai.net" + window.location.pathname + window.location.search + window.location.hash
        }, "use strict", e.reader = function(t) {
            e.extend(this, t), this.num_pages = this.gallery.images.pages.length, this.gallery_url = e.format("/g/{0}/", this.gallery.id), this.current_page = null, this.$image_container = document.querySelector("#image-container"), this.apply_settings(), this.install_scroller(), this.install_link_catcher(), this.install_image_navigation(), this.image_cache = {}, this.preload_queue = [], this.direction = 1, this.get_image(this.start_page, document.querySelector("#image-container img"));
            var n = this;
            e.bind(window, "popstate", function(e) {
                e.state && e.state.page && n.set_page(e.state.page, !1)
            })
        }, e.reader.prototype.update_direction = function(e, t) {
            e + 1 === t ? this.direction = Math.min(3, this.direction + 1) : e - 1 === t && (this.direction = Math.max(-3, this.direction - 1)), console.log("Direction is now", this.direction)
        }, e.reader.prototype.maybe_preload = function() {
            var t = reader.get_settings().preload,
                n = [];
            if (this.direction >= 0) var r = Math.min(reader.current_page + 1, reader.num_pages),
                i = Math.min(reader.num_pages, reader.current_page + t) + 1,
                s = 1;
            else var r = Math.max(1, reader.current_page - 1),
                i = Math.max(1, reader.current_page - t) - 1,
                s = -1;
            var n = e.range(r, i, s);
            reader.preload_pages(n)
        }, e.reader.prototype.preload_pages = function(t) {
            if (!t.length) return;
            var n = this;
            this.preload_timer && (clearTimeout(this.preload_timer), this.preload_timer = null), this.preload_timer = setTimeout(function() {
                do {
                    var r = t[0];
                    t.shift()
                } while (t.length && r in n.image_cache);
                console.log("Preloading page", r);
                var i = n.get_image(r);
                e.bind(i.image, "load", function() {
                    n.preload_pages(t)
                })
            }, 100)
        }, e.reader.prototype.apply_settings = function() {
            var e = this.get_settings();
            this.$image_container.className = e.image_scaling, e.show_navbar ? document.documentElement.classList.remove("nav-hidden") : document.documentElement.classList.add("nav-hidden")
        }, e.reader.prototype.get_settings = function(t) {
            return e.storage.get("settings", {
                reader: {
                    preload: 3,
                    turning_behavior: "right",
                    image_scaling: "fit-horizontally",
                    show_navbar: !0,
                    scroll_on_turn: !0
                }
            }).reader
        }, e.reader.prototype.get_page_url = function(t) {
            return e.format("/g/{0}/{1}/", this.gallery.id, t)
        }, e.reader.prototype.get_extension = function(e) {
            return {
                j: "jpg",
                p: "png",
                g: "gif"
            }[this.gallery.images.pages[e - 1].t]
        }, e.reader.prototype.get_image_url = function(t) {
            return e.format("{0}galleries/{1}/{2}.{3}", this.media_url, this.gallery.media_id, t, this.get_extension(t))
        }, e.reader.prototype.get_thumbnail_url = function(t) {
            return e.format("{0}galleries/{1}/{2}t.{3}", this.media_url, this.gallery.media_id, t, this.get_extension(t))
        }, e.reader.prototype.get_image = function(t, n) {
            if (!(t in this.image_cache)) {
                n || (n = new Image, n.src = this.get_image_url(t)), this.image_cache[t] = {
                    image: n,
                    loaded: !1
                }, n.width = this.gallery.images.pages[t - 1].w, n.height = this.gallery.images.pages[t - 1].h;
                var r = this;
                e.bind(n, "load", function() {
                    r.image_cache[t].loaded = !0, r.current_page === t && r.maybe_preload()
                })
            }
            return this.image_cache[t]
        }, e.reader.prototype.set_page = function(e, t, n) {
            var r = this;
            if (e === this.current_page) return;
            this.update_direction(this.current_page, e), console.debug("Switching to page", e), this.current_page = e, this.update_pagination(e);
            var i = document.querySelector("#image-container img"),
                s = this.get_image(e);
            i !== s.image && (i.parentNode.appendChild(s.image), i.parentNode.removeChild(i)), s.loaded && this.maybe_preload(), t && history.pushState && (history.pushState({
                page: e
            }, document.title, this.get_page_url(e)), window.ga("send", "pageview", window.location.pathname)), this.get_settings().scroll_on_turn && this.$image_container.scrollIntoView()
        }, e.reader.prototype.previous_page = function() {
            this.set_page(Math.max(1, this.current_page - 1), !0)
        }, e.reader.prototype.next_page = function() {
            this.set_page(Math.min(this.current_page + 1, this.num_pages), !0)
        }, e.reader.prototype.update_pagination = function(t) {
            this.$image_container.querySelector("a").href = t < this.num_pages ? this.get_page_url(t + 1) : this.gallery_url, document.title = document.title.replace(/Page (\d+) \u00bb/, e.format("Page {0} \u00bb", t));
            var n = e.render_template('\n		<% if (page > 1) { %>\n				<a href="<%= r.get_page_url(1) %>" class="first"><i class="fa fa-chevron-left"></i><i class="fa fa-chevron-left"></i></a>\n				<a href="<%= r.get_page_url(page - 1) %>" class="previous"><i class="fa fa-chevron-left"></i></a>\n		<% } else { %>\n				<a class="first invisible"><i class="fa fa-chevron-left"></i><i class="fa fa-chevron-left"></i></a>\n				<a class="previous invisible"><i class="fa fa-chevron-left"></i></a>\n		<% } %>\n\n		<span class="page-number"><span class="current"><%= page %></span> <span class="divider">of</span> <span class="num-pages"><%= r.num_pages %></span></span>\n\n		<% if (page < r.num_pages) { %>\n				<a href="<%= r.get_page_url(page + 1) %>" class="next"><i class="fa fa-chevron-right"></i></a>\n				<a href="<%= r.get_page_url(r.num_pages) %>" class="last"><i class="fa fa-chevron-right"></i><i class="fa fa-chevron-right"></i></a>\n		<% } else { %>\n				<a class="next invisible"><i class="fa fa-chevron-right"></i></a>\n				<a class="last invisible"><i class="fa fa-chevron-right"></i><i class="fa fa-chevron-right"></i></a>\n		<% } %>\n	', {
                r: this,
                page: t
            });
            document.querySelector("#pagination-page-bottom").innerHTML = n, document.querySelector("#pagination-page-top").innerHTML = n
        }, e.reader.prototype.install_scroller = function() {
            var t = this,
                n = null;
            e.bind(document, "keydown", function(
                r) {
                if (r.target.tagName.toLowerCase() === "input" || r.metaKey || r.ctrlKey || r.shiftKey || r.altKey) return;
                n && (clearInterval(n), n = null);
                var i = !0;
                switch (r.which) {
                    case e.key.S:
                    case e.key.DOWN_ARROW:
                        n = setInterval(function() {
                            window.scrollBy(0, 5)
                        }, 5);
                        break;
                    case e.key.W:
                    case e.key.UP_ARROW:
                        n = setInterval(function() {
                            window.scrollBy(0, -5)
                        }, 5);
                        break;
                    case e.key.A:
                    case e.key.LEFT_ARROW:
                        t.previous_page();
                        break;
                    case e.key.D:
                    case e.key.RIGHT_ARROW:
                        t.next_page();
                        break;
                    default:
                        i = !1
                }
                i && r.preventDefault()
            }), e.bind(document, "keyup visibilitychange", function() {
                n && (clearInterval(n), n = null)
            })
        }, e.reader.prototype.install_link_catcher = function() {
            var t = this;
            e.bind(".pagination", "a", "click", function(e) {
                var n = this.href.match(new RegExp("/g/\\d+/(\\d+)"));
                n && (e.preventDefault(), t.set_page(parseInt(n[1], 10), !0))
            }, !0)
        }, e.reader.prototype.install_image_navigation = function() {
            var t = this,
                n = new e.debouncer(500);
            e.bind("#image-container", "img", "click", function(e) {
                e.preventDefault();
                if (!n.is_ready()) return;
                n.hit();
                var r = t.get_settings().turning_behavior,
                    i;
                typeof e.offsetX == "undefined" ? i = e.pageX - (this.getBoundingClientRect().left - document.body.getBoundingClientRect().left) : i = e.offsetX;
                var s = i / this.width;
                r === "both" || r === "left" && s < .6 || r === "right" && s > .4 ? t.current_page === t.num_pages ? window.location = t.gallery_url : t.next_page() : t.previous_page()
            })
        }, e.reader.prototype.install_settings_button = function() {
            var t = this,
                n = document.querySelector(".reader-settings");
            e.bind(n, "click", function() {
                var n = e.create_element('\n			<label>Image Preloading <select id="preload">\n				<option value="0">Disabled</option>\n				<option value="1">1 page</option>\n				<option value="2">2 pages</option>\n				<option value="3">3 pages</option>\n				<option value="4">4 pages</option>\n				<option value="5">5 pages</option>\n			</select></label>\n\n			<label>Page Turning <select id="turning_behavior">\n				<option value="left">Left half</option>\n				<option value="right">Right half</option>\n				<option value="both">Entire image</option>\n			</select></label>\n\n			<label>Image Scaling <select id="image_scaling">\n				<option value="fit-horizontal">Fit horizontally</option>\n				<option value="fit-both">Fit on screen</option>\n				<option value="fit-none">Disabled</option>\n			</select></label>\n\n			<label>Navigation Bar <select id="show_navbar">\n				<option value="false">Hide</option>\n				<option value="true">Show</option>\n			</select></label>\n\n			<label>Scroll on Page Turn <select id="scroll_on_turn">\n				<option value="true">Top of image</option>\n				<option value="false">Don\'t scroll</option>\n			</select></label>\n		'),
                    r = t.get_settings();
                for (var i = 0, s = e.keys(r); i < s.length; i++) {
                    var o = s[i];
                    n.getElementById(o).value = r[o]
                }
                var u = new e.modal("Reader Settings", n, [{
                    type: "primary",
                    name: "Save",
                    callback: function(r, i) {
                        var s = {},
                            o = i.$wrapper.querySelectorAll("select");
                        for (var u = 0; u < o.length; u++) s[o[u].id] = o[u].value;
                        s.preload = Number(s.preload), s.show_navbar = s.show_navbar === "true", s.scroll_on_turn = s.scroll_on_turn === "true";
                        var a = e.storage.get("settings", {
                            storage: {}
                        });
                        a.reader = s, e.storage.set("settings", a), t.apply_settings(), i.close()
                    }
                }, {
                    type: "secondary",
                    name: "Cancel",
                    callback: function(n, r) {
                        t.apply_settings(), r.close()
                    }
                }]);
                u.show()
            })
        }, "use strict", e.relative_time = function(t) {
            function i(t, n) {
                var t = Math.floor(t);
                return t > 1 ? e.format("{0} {1}s ago", t, n) : e.format("{0} {1} ago", t, n)
            }
            var n = new Date,
                t = new Date(t),
                r = (n - t) / 1e3;
            return r < 60 ? i(r, "second") : r / 60 < 60 ? i(r / 60, "minute") : r / 60 / 60 < 24 ? i(r / 60 / 60, "hour") : r / 60 / 60 / 24 < 7 ? i(r / 60 / 60 / 24, "day") : r / 60 / 60 / 24 <= 30 ? i(r / 60 / 60 / 24 / 7, "week") : r / 60 / 60 / 24 / 30 < 12 ? i(r / 60 / 60 / 24 / 30, "month") : i(r / 60 / 60 / 24 / 365, "year")
        }, e.update_times = function() {
            var t = 6e4,
                n = document.querySelectorAll("time[datetime]");
            for (var r = 0; r < n.length; r++) {
                var i = n[r],
                    s = e.relative_time(i.getAttribute("datetime"));
                i.innerHTML !== s && (i.innerHTML = s), s.indexOf("second") !== -1 && (t = 1e3)
            }
            return t
        }, e.install_relative_time = function() {
            e.ready(function() {
                var t = function n() {
                    var t = e.update_times();
                    setTimeout(n, t)
                };
                t()
            })
        }, "use strict", e.blacklist_tags = function(e) {
            this.tag_ids = e
        }, e.blacklist_tags.prototype.apply_css = function() {
            if (!this.tag_ids || !this.tag_ids.length) return;
            var t = this.tag_ids.map(function(t) {
                    return e.format('.gallery[data-tags~="{0}"]', t)
                }).join(",") + "," + this.tag_ids.map(function(t) {
                    return e.format(".tag-{0}", t)
                }).join(","),
                n = document.querySelectorAll(t);
            for (var r = 0; r < n.length; r++) n[r].classList.add("blacklisted")
        }, "use strict", e.CRC = {}, e.CRC.table = null, e.CRC.compute_table = function() {
            var e = [];
            for (var t = 0; t < 256; t++) {
                var n = t;
                for (var r = 0; r < 8; r++) n = n & 1 ? 3988292384 ^ n >>> 1 : n >>> 1;
                e[t] = n
            }
            return e
        }, e.CRC.crc32 = function(t) {
            var n = -1,
                r = e.CRC.table || (e.CRC.table = e.CRC.compute_table()),
                i;
            t instanceof ArrayBuffer ? i = t.byteLength : i = t.length;
            for (var s = 0; s < i; s++) n = n >>> 8 ^ r[(n ^ t[s]) & 255];
            return ~n
        }, "use strict", s.prototype.resize_to_fit = function(e) {
            if (e <= this.length) return;
            if (e > this.array.length) {
                console.log("Resizing", this.array.length, "->", e);
                var t = new Uint8Array(o(e));
                t.set(this.array, 0), this.array = t
            }
            this.view = new DataView(this.array.buffer, 0, e), this.length = e
        }, s.prototype.extend = function(e) {
            this.resize_to_fit(this.offset + e.length), u(this.array, e.array, 0, e.length, this.offset), this.offset += e.length
        }, s.prototype.write_array = function(e) {
            this.resize_to_fit(this.offset + e.length), this.array.set(e, this.offset), this.offset += e.length
        }, s.prototype.write_short = function(e) {
            this.resize_to_fit(this.offset + 2), this.view.setUint16(this.offset, e, !0), this.offset += 2
        }, s.prototype.write_int = function(e) {
            this.resize_to_fit(this.offset + 4), this.view.setUint32(this.offset, e, !0), this.offset += 4
        }, s.prototype.write_bytes = function(e) {
            this.resize_to_fit(this.offset + e.length);
            for (var t = 0; t < e.length; t++) this.view.setUint8(this.offset++, e.charCodeAt(t), !0)
        }, s.prototype.to_blob = function(e) {
            try {
                return new Blob([this.view], {
                    type: e
                })
            } catch (t) {
                var n = new(window.BlobBuilder || window.WebKitBlobBuilder || window.MozBlobBuilder || window.MSBlobBuilder),
                    r = new ArrayBuffer(this.length),
                    i = new Uint8Array(r);
                return u(i, this.array, 0, this.length, 0), n.append(r), n.getBlob(e)
            }
        }, e.zipfile = function(e, t) {
            this.has_download_attribute = "download" in document.createElementNS("http://www.w3.org/1999/xhtml", "a");
            if (!(window.Uint8Array && window.URL && URL.createObjectURL && window.Blob)) throw new Error("Browser cannot create blobs");
            if (!(this.has_download_attribute || window.saveAs || navigator.msSaveOrOpenBlob)) throw new Error("Browser cannot save blobs");
            this.file_data = new s(12e6), this.central_directory = new s(5200), this.cdr_count = 0, this.filename = e, this.total_requests = 0, this.request_count = 0;
            for (var n = 0; n < t.length; n++) this.add_url(t[n][0], t[n][1]);
            this.done = function() {}, this.progress = function(e, t) {}, this.send_progress()
        }, e.zipfile.prototype.CENTRAL_DIRECTORY_HEADER = "PK", e.zipfile.prototype.LOCAL_FILE_HEADER = "PK", e.zipfile.prototype.CENTRAL_DIRECTORY_HEADER_END = "PK", e.zipfile.prototype.shared_header = function(t, n) {
            var r = new s(26);
            return r.write_short(20), r.write_short(0), r.write_short(0), r.write_short(0), r.write_short(33), r.write_int(e.CRC.crc32(n)), r.write_int(n.length), r.write_int(n.length), r.write_short(t.length), r.write_short(0), r
        }, e.zipfile.prototype.add_file = function(e, t) {
            var n = this.shared_header(e, t),
                r = this.file_data.length;
            this.file_data.write_bytes(this.LOCAL_FILE_HEADER), this.file_data.extend(n), this.file_data.write_bytes(e + ""), this.file_data.write_array(t), this.cdr_count++, this.central_directory.write_bytes(this.CENTRAL_DIRECTORY_HEADER), this.central_directory.write_short(20), this.central_directory.extend(n), this.central_directory.write_short(0), this.central_directory.write_short(0), this.central_directory.write_short(0), this.central_directory.write_int(0), this.central_directory.write_int(r), this.central_directory.write_bytes(e), n = null
        }, e.zipfile.prototype.cdr_end = function() {
            var e = new s(50);
            return e.write_bytes(this.CENTRAL_DIRECTORY_HEADER_END), e.write_short(0), e.write_short(0), e.write_short(this.cdr_count), e.write_short(this.cdr_count), e.write_int(this.central_directory.length), e.write_int(this.file_data.length), e.write_short(0), e
        }, e.zipfile.prototype.save_blob = function() {
            var e = this.cdr_end(),
                t = new s(this.file_data.length + this.central_directory.length + e.length);
            return t.extend(this.file_data), t.extend(this.central_directory), t.extend(e), t.to_blob("application/zip")
        }, e.zipfile.prototype.download = function() {
            var e = this.save_blob(),
                t = URL.createObjectURL(e);
            if (window.saveAs) saveAs(e, this.filename);
            else if (navigator.msSaveOrOpenBlob) navigator.msSaveOrOpenBlob(e, this.filename);
            else {
                if (!this.has_download_attribute) throw new Error("Your browser can't handle JS downloads");
                var n = document.createElement("a");
                n.style.display = "none", n.href = t, n.download = this.filename, document.body.appendChild(n), n.click(), setTimeout(function() {
                    document.body.removeChild(n), window.URL.revokeObjectURL(t)
                }, 3e3)
            }
        }, e.zipfile.prototype.add_url = function(t, n) {
            var r = this;
            this.request_count++, this.total_requests++, e.http({
                method: "GET",
                url: n,
                xhr_properties: {
                    responseType: "arraybuffer"
                },
                default_headers: !1,
                success: function() {
                    r.add_file(t, new Uint8Array(this.response)), r.file_downloaded()
                },
                failure: function(t) {
                    r.error(t)
                }
            })
        }, e.zipfile.prototype.file_downloaded = function() {
            this.request_count--, this.send_progress(), this.request_count === 0 && this.done()
        }, e.zipfile.prototype.send_progress = function() {
            this.progress(this.total_requests - this.request_count, this.total_requests)
        }, e.zipfile.prototype.error = function(e) {}, "use strict", e.tag = function(e, t, n, r, i) {
            var s = arguments.length <= 5 || arguments[5] === undefined ? !1 : arguments[5];
            this.id = e, this.name = t, this.type = n, this.url = r, this.count = i, this.created = s
        }, e.tag.prototype.as_object = function() {
            return {
                id: this.id,
                name: this.name,
                type: this.type
            }
        }, e.tag.prototype.as_element = function() {
            var t = document.createElement("a");
            t.href = this.url, t.classList.add("tag"), t.classList.add("tag-" + this.id);
            var n = document.createElement("span");
            n.textContent = this.name, t.appendChild(n), t.appendChild(document.createTextNode(" "));
            var r = document.createElement("span");
            return r.classList.add("count"), this.created ? (r.textContent = "(create)", t.classList.add("tag-created")) : r.textContent = "(" + e.pretty_integer(this.count) + ")", t.appendChild(r), t.tag = this, t
        }, e.gallery = function(t) {
            for (var n = 0; n < t.tags.length; n++) {
                var r = t.tags[n];
                t.tags[n] = new e.tag(r.id, r.name, r.type, r.url, r.count)
            }
            e.extend(this, t), this.editing = !1
        }, e.gallery.prototype.get_url = function(t) {
            return e.format("/g/{0}/{1}", this.id, t)
        }, e.gallery.prototype.toggle_favorite = function() {
            document.querySelector("#favorite").disabled = !0, e.http({
                method: "POST",
                url: this.get_url("favorite"),
                success: function() {
                    var t = JSON.parse(this.response),
                        n = document.querySelector("#favorite i.fa");
                    document.querySelector("#favorite .count").textContent = t.count, document.querySelector("#favorite .text").textContent = t.favorited ? "Unfavorite" : "Favorite", document.querySelector("#favorite").disabled = !1, n.classList.toggle("fa-heart"), n.classList.toggle("fa-heart-o")
                }
            })
        }, e.gallery.prototype.download_zipfile = function() {
            var t = [],
                n = this.images.pages.toString().length;
            for (var r = 0; r < this.images.pages.length; r++) {
                var i = e.pad((r + 1).toString(), n, "0"),
                    s = {
                        j: "jpg",
                        p: "png",
                        g: "gif"
                    }[this.images.pages[r].t],
                    o = e.format("//i.nhentai.net/galleries/{0}/{1}.{2}", this.media_id, r + 1, s);
                t.push([e.format("{0}.{1}", i, s), o])
            }
            var u = new e.zipfile(this.title.pretty + ".zip", t);
            u.done = function() {
                u.download()
            };
            var a = document.querySelector("#download");
            u.progress = function(t, n) {
                a.textContent = e.format("Downloaded {0} of {1}: {2}%", t, n, (100 * t / n).toFixed(2))
            }
        }, e.gallery.prototype.toggle_edit = function() {
            this.editing ? (this.editing = !1, document.querySelector("#edit .text").textContent = "Edit", document.querySelector("#edit").disabled = !0, this.end_edit()) : (this.editing = !0, document.querySelector("#edit .text").textContent = "Save", this.begin_edit())
        }, e.gallery.prototype.begin_edit = function() {
            var t = ["parody", "character", "tag", "artist", "group", "language", "category"],
                n = {
                    tag: [],
                    artist: [],
                    parody: [],
                    character: [],
                    group: [],
                    language: [],
                    category: []
                },
                r = {
                    tag: "Tags",
                    artist: "Artists",
                    parody: "Parodies",
                    character: "Characters",
                    group: "Groups",
                    language: "Languages",
                    category: "Categories"
                };
            for (var i = 0; i < this.tags.length; i++) {
                var s = this.tags[i];
                n[s.type].push(s)
            }
            this.editors = [], document.querySelector("#tags").innerHTML = "";
            for (var i = 0; i < t.length; i++) {
                var o = new e.tag_editor(t[i], n[t[i]], !0);
                this.editors.push(o), o.$wrapper.querySelector(".name").textContent = r[t[i]] + ":", document.querySelector("#tags").appendChild(o.$wrapper), o.begin_edit()
            }
        }, e.gallery.prototype.end_edit = function() {
            var t = [],
                n = [],
                r = [];
            for (var i = 0; i < this.editors.length; i++) {
                var s = this.editors[i];
                s.end_edit();
                var o = s.state();
                for (var u = 0; u < o.added.length; u++) {
                    var a = o.added[u];
                    a.id.toString().indexOf("new-") !== -1 ? n.push({
                        name: a.name,
                        type: a.type
                    }) : t.push(a.id)
                }
                for (var u = 0; u < o.removed.length; u++) {
                    var a = o.removed[u];
                    a.id.toString().indexOf("new-") === -1 && r.push(a.id)
                }
            }
            e.http({
                url: this.get_url("edit"),
                method: "POST",
                json: {
                    added_tags: t,
                    removed_tags: r,
                    created_tags: n
                },
                success: function() {
                    debugger;
                    var n = JSON.parse(this.response);
                    n.error ? e.show_message("An error has occured: " + n.error, "danger") : e.show_message("Your edit has been saved and will be approved shortly", "success")
                },
                failure: function(n) {
                    var r = JSON.parse(this.response);
                    e.show_message("An error has occured: " + r.error, "danger")
                }
            })
        }, "use strict", e.tag_autocomplete = function(t, n, r) {
            var i = arguments.length <= 3 || arguments[3] === undefined ? {} : arguments[3];
            this.tag = t, this.type = n, this.editor = r, this.exclude = i, this.$wrapper = e.create_element('\n		<div class="tag-autocomplete">\n			<div class="autocomplete-wrapper">\n				<input type="text" class="tag tag-input" placeholder="enter a tag name" autocapitalize="none" />\n				<ul class="dropdown"></ul>\n			</div>\n\n			<div class="tag-wrapper"></div>\n		</div>\n	'), this.$autocomplete_wrapper = this.$wrapper.querySelector(".autocomplete-wrapper"), this.$tag_wrapper = this.$wrapper.querySelector(".tag-wrapper"), this.$input = this.$autocomplete_wrapper.querySelector("input"), this.$dropdown = this.$autocomplete_wrapper.querySelector("ul"), this.install_handlers()
        }, e.tag_autocomplete.prototype.install_handlers = function() {
            var t = this;
            e.bind(this.$input, "keydown", function(n) {
                var r = t.$dropdown.querySelector("li.active"),
                    i = t.$dropdown.querySelector("li"),
                    s = !!r;
                r = r || i;
                if (n.which === e.key.ESCAPE || this.value === "" && n.which === e.key.BACKSPACE) n.preventDefault(), this.focus(), t.remove();
                else if (n.which === e.key.UP_ARROW) r.classList.remove("active"), (e.find_previous(r, "li:not(.disabled)") || r).classList.add("active");
                else if (n.which === e.key.DOWN_ARROW) s ? (r.classList.remove("active"), (e.find_next(r, "li:not(.disabled)") || r).classList.add("active")) : r.classList.add("active");
                else if (n.which === e.key.ENTER) {
                    if (t.$dropdown.children.length === 1) r = t.$dropdown.children[0];
                    else if (!s) return;
                    var o = r.querySelector("a");
                    t.select_tag(o)
                }
            }), e.bind(this.$dropdown, "li, a", "click", function(n) {
                var r = e.matches(this, "a") ? this : this.querySelector("a");
                t.select_tag(r), n.preventDefault()
            }), e.bind(this.$dropdown, "li:not(.disabled)", "hover", function(e) {
                var n = t.$dropdown.querySelector("li.active");
                if (n === this) return;
                n && n.classList.remove("active"), this.classList.add("active")
            }), e.bind(this.$tag_wrapper, ".tag", "click", function(e) {
                var n = t.$tag_wrapper.children[0],
                    r = "";
                n && (r = n.tag.name), t.$autocomplete_wrapper.classList.remove("hidden"), t.$tag_wrapper.innerHTML = "", t.$input.value = r, t.$input.focus(), e.preventDefault(), e.stopPropagation()
            }, {
                capture: !0
            }), this.old_value = "", e.bind(this.$input, "keyup", function(e) {
                this.value !== t.old_value && (t.show_autocomplete(this.value), t.old_value = this.value)
            }), setTimeout(function() {
                e.bind(document, "click", function(e) {
                    if (t.$autocomplete_wrapper.classList.contains("hidden")) return;
                    if (t.$wrapper.contains(e.target)) return;
                    if (t.$wrapper === e.target) return;
                    t.remove()
                }, {
                    capture: !1
                })
            }, 100)
        }, e.tag_autocomplete.prototype.remove = function() {
            this.editor.added_tags.splice(this.editor.added_tags.indexOf(this.tag), 1), this.$wrapper.parentNode.removeChild(this.$wrapper)
        }, e.tag_autocomplete.prototype.select_tag = function(t) {
            e.extend(this.tag, t.tag), t.classList.add("tag-added"), this.$tag_wrapper.appendChild(t), this.$autocomplete_wrapper.classList.add("hidden")
        }, e.tag_autocomplete.prototype.show_autocomplete = function(t) {
            var n = this;
            e.http({
                url: "/api/autocomplete",
                method: "POST",
                params: {
                    name: t,
                    type: this.type
                },
                success: function() {
                    n.$dropdown.innerHTML = "";
                    var i = JSON.parse(this.response),
                        s = !1;
                    for (var o = 0; o < i.result.length; o++) {
                        var u = i.result[o];
                        if (n.exclude[u.id]) continue;
                        s = !0;
                        var a = new e.tag(u.id, u.name, u.type, u.url, u.count),
                            f = document.createElement("li");
                        f.appendChild(a.as_element()), n.$dropdown.appendChild(f)
                    }
                    if (e.strip(t)) {
                        var f = document.createElement("li");
                        n.editor.create ? (n.tag.name = e.strip(t), n.tag.created = !0, f.appendChild(n.tag.as_element())) : s || (f.classList.add("disabled"), f.appendChild(document.createTextNode("no results"))), n.$dropdown.appendChild(f)
                    }
                }
            })
        }, e.tag_editor = function(t) {
            var n = arguments.length <= 1 || arguments[1] === undefined ? [] : arguments[1],
                r = arguments.length <= 2 || arguments[2] === undefined ? !1 : arguments[2];
            this.type = t, this.tags = {}, this.create = r, this.removed_tags = {}, this.added_tags = [], this.autocomplete_excluded_tags = {}, this.new_tag_counter = 0, this.$wrapper = e.create_element('\n		<div class="tag-container field-name">\n			<span class="name"></span>\n			<span class="tags"></span>\n		</div>\n	', {
                type: this.type
            });
            for (var i = 0; i < n.length; i++) this.tags[n[i].id] = n[i], this.$wrapper.appendChild(n[i].as_element());
            this.editing = !1, this.recompute_excluded_tags()
        }, e.tag_editor.prototype.recompute_excluded_tags = function() {
            var t = e.keys(this.autocomplete_excluded_tags);
            for (var n = 0; n < t.length; n++) delete this.autocomplete_excluded_tags[t[n]];
            var r = e.keys(this.tags);
            Array.prototype.push.apply(r, this.added_tags.map(function(e) {
                return e.id
            })), Array.prototype.push.apply(r, e.keys(this.removed_tags));
            for (var n = 0; n < r.length; n++) this.autocomplete_excluded_tags[r[n]] = !0
        }, e.tag_editor.prototype.begin_edit = function() {
            if (this.editing) throw new Error("Already editing");
            this.editing = !0;
            var t = this;
            this.tag_click_callback = e.bind(this.$wrapper, ".tag-container > .tag", "click", function(e) {
                if (this.classList.contains("tag-new") || this.classList.contains("tag-added")) return;
                e.preventDefault(), this.classList.contains("tag-deleted") ? delete t.removed_tags[this.tag.id] : t.removed_tags[this.tag.id] = t.tags[this.tag.id], this.classList.toggle("tag-deleted"), t.recompute_excluded_tags()
            });
            var n = e.create_element('<a class="tag tag-new">+</a>');
            e.bind(n, "click", function() {
                var n = new e.tag("new-" + t.new_tag_counter++, "", t.type, "#", 0);
                t.added_tags.push(n), t.recompute_excluded_tags();
                var r = new e.tag_autocomplete(n, t.type, t, t.autocomplete_excluded_tags);
                this.parentNode.insertBefore(r.$wrapper, this), r.$input.focus(), r.show_autocomplete("")
            }), this.$wrapper.appendChild(n)
        }, e.tag_editor.prototype.end_edit = function() {
            if (!this.editing) throw new Error("Not editing");
            this.editing = !1;
            var e = this.$wrapper.querySelectorAll(".tag-new");
            for (var t = 0; t < e.length; t++) e[t].parentNode.removeChild(e[t])
        }, e.tag_editor.prototype.state = function() {
            var t = [];
            for (var n = 0, r = e.keys(this.removed_tags); n < r.length; n++) t.push(this.removed_tags[r[n]]);
            return {
                added: this.added_tags,
                removed: t
            }
        }, "use strict", e.install_menu_events = function() {
            function r() {
                t.classList.toggle("open"), n.querySelector("i").classList.toggle("fa-chevron-down"), n.querySelector("i").classList.toggle("fa-chevron-up")
            }
            var t = document.querySelector(".dropdown-menu"),
                n = document.querySelector("#dropdown");
            e.bind(n, "click", function() {
                r(), n.querySelector("i").classList.contains("fa-chevron-up") && setTimeout(function() {
                    var i = e.bind(document, "click", function(s) {
                        e.unbind(document, "click", i, {
                            capture: !1
                        }), !t.contains(s.target) && !n.contains(s.target) && r()
                    }, {
                        capture: !1
                    })
                }, 100)
            }), e.bind(document.querySelector("#hamburger"), "click", function() {
                document.querySelector(".collapse").classList.toggle("open")
            })
        }, "use strict", e.install_favorites_events = function() {
            e.bind("#favcontainer", ".gallery-favorite .remove-button", "click", function() {
                var t = this,
                    n = e.find_parent(this, ".gallery-favorite"),
                    r = parseInt(n.dataset.id, 10),
                    i = new e.gallery({
                        id: r,
                        tags: []
                    }),
                    s = setTimeout(function() {
                        t.querySelector(".text").textContent = "Loading..."
                    }, 200);
                e.http({
                    url: i.get_url("favorite"),
                    method: "POST",
                    success: function() {
                        clearTimeout(s);
                        var r = JSON.parse(this.response);
                        r.favorited ? (n.classList.remove("removed"), t.querySelector(".text").textContent = "Remove", t.querySelector(".fa").classList.add("fa-minus"), t.querySelector(".fa").classList.remove("fa-undo")) : (n.classList.add("removed"), t.querySelector(".text").textContent = "Undo", t.querySelector(".fa").classList.remove("fa-minus"), t.querySelector(".fa").classList.add("fa-undo"))
                    }
                })
            })
        }, "use strict", e.modal = function(e, t, n) {
            this.title = e, this.$wrapper = null, this._$content = t, this.buttons = n
        }, e.modal.prototype.show = function() {
            var t = document.createElement("div");
            t.classList.add("modal-inner");
            var n = document.createElement("h1");
            n.textContent = this.title, t.appendChild(n);
            var r = document.createElement("div");
            r.classList.add("contents"), r.appendChild(this._$content), t.appendChild(r);
            var i = document.createElement("div");
            i.classList.add("buttons");
            for (var s = 0; s < this.buttons.length; s++) {
                var o = this.buttons[s],
                    u = document.createElement("button");
                u.type = "button", u.classList.add("btn"), u.classList.add("btn-" + o.type), u.textContent = o.name,
                    function(t, n) {
                        e.bind(u, "click", function(e) {
                            return t(e, n)
                        })
                    }(o.callback, this), i.appendChild(u)
            }
            t.appendChild(i), this.$wrapper = document.createElement("div"), this.$wrapper.classList.add("modal-wrapper"), this.$wrapper.appendChild(t);
            var a = this;
            e.bind(this.$wrapper, "click", function(e) {
                e.target === a.$wrapper && a.close()
            }), document.body.appendChild(this.$wrapper)
        }, e.modal.prototype.close = function() {
            this.$wrapper.parentNode.removeChild(this.$wrapper)
        }
}).call(this);