$(document).ready(function() {
    $("#ex1").click(function() {
        $("#searchq").val("+yaoi,+anal,+group"), $("#form_search").get(0).setAttribute("action", "/search/+yaoi,+anal,+group/")
    }), $("#ex2").click(function() {
        $("#searchq").val("-glasses,-incest,-stockings"), $("#form_search").get(0).setAttribute("action", "/search/-glasses,-incest,-stockings/")
    }), $("#ex3").click(function() {
        $("#searchq").val("+lolicon,-blowjob,+english,+rape,-sister"), $("#form_search").get(0).setAttribute("action", "/search/+lolicon,-blowjob,+english,+rape,-sister/")
    }), $("#dropmenu").click(function() {
        $("#header .right .search .dropmenu").slideToggle()
    }), $("#searchq").on("input", function() {
        var e = $("#searchq").val(),
            t = e.replace(/\s+/g, "+").toLowerCase();
        $("#form_search").get(0).setAttribute("action", "/search/" + t + "/")
    }), $("#searchq_m").on("input", function() {
        var e = $("#searchq_m").val(),
            t = e.replace(/\s+/g, "+").toLowerCase();
        $("#form_search_m").get(0).setAttribute("action", "/search/" + t + "/")
    }), $("#jumpto_up, #jumpto_down").on("change", function() {
        $(location).attr("href", this.value)
    }), $(".floatpc").hide(), $(".floatmb").hide(), $(".ads_under_details").hide()
})