function user_lang() {
    var n = navigator.language || navigator.userLanguage;
    return n.toLowerCase()
}

function is_english() {
    var n = user_lang();
    return /^en/.test(n)
}

function is_asian() {
    var n = user_lang();
    return /^(?:ko|ja)/.test(n)
}

function random_index(n) {
    return Math.floor(Math.random() * n.length)
}

function random_property(n) {
    var r, t = 0;
    for (var e in n) Math.random() < 1 / ++t && (r = e);
    return r
}

function hitomi_inject(n, r) {
    $(n).html($(n).html() + r)
}

function get_json_cookie(n) {
    var r = {},
        t = Cookies.getJSON(n);
    return t && (r = t), r
}
Object.keys || (Object.keys = function() {
    "use strict";
    var n = Object.prototype.hasOwnProperty,
        r = !{
            toString: null
        }.propertyIsEnumerable("toString"),
        t = ["toString", "toLocaleString", "valueOf", "hasOwnProperty", "isPrototypeOf", "propertyIsEnumerable", "constructor"],
        e = t.length;
    return function(o) {
        if ("object" != typeof o && ("function" != typeof o || null === o)) throw new TypeError("Object.keys called on non-object");
        var a, u, i = [];
        for (a in o) n.call(o, a) && i.push(a);
        if (r)
            for (u = 0; e > u; u++) n.call(o, t[u]) && i.push(t[u]);
        return i
    }
}());
var rand = function(n, r) {
        return Math.random() * (r - n) + n
    },
    getRandomItem = function(n, r) {
        for (var t = r.reduce(function(n, r, t, e) {
                return n + r
            }), e = rand(0, t), o = 0, a = 0; a < n.length; a++)
            if (o += r[a], o = +o.toFixed(2), o >= e) return n[a]
    }